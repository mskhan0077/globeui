import type { Assumptions, Candidate, LoadSpec, SimResult, SiteData, TechScore } from "@/lib/engine";
import { GEN_KEYS, TECH_LABEL, dieselEF } from "@/lib/engine";

export interface ExportInput {
  siteName: string;
  lat: number;
  lon: number;
  site: SiteData;
  distanceKm: number;
  load: LoadSpec;
  assumptions: Assumptions;
  result: SimResult;
  ranked: Candidate[];
  tech: TechScore[];
}

const r = (v: number, d = 2) => (Number.isFinite(v) ? Number(v.toFixed(d)) : "");
const esc = (v: unknown) => {
  const s = String(v ?? "");
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
};
const row = (cells: unknown[]) => cells.map(esc).join(",");

export function buildCSV(x: ExportInput): string {
  const c = x.result.config;
  const lines: string[] = [];
  lines.push(row(["BlueGrid summary (dummy dataset – not for investment decisions)"]));
  lines.push(row(["Site", x.siteName]), row(["Latitude", x.lat]), row(["Longitude", x.lon]));
  lines.push(row(["Resource data from", `${x.site.island.name} (${r(x.distanceKm, 1)} km)`]));
  lines.push(row(["Load target kW", x.load.kw]), row(["Load profile", x.load.profile]));
  lines.push("");
  lines.push(row(["Configuration", "Wind kW", "Floating solar kWp", "OTEC kW", "Wave kW", "BESS kWh"]));
  lines.push(row(["Selected", c.wind, c.fpv, c.otec, c.wave, c.bess]));
  lines.push("");
  const k = x.result;
  lines.push(row(["Metric", "Value", "Unit"]));
  [
    ["RE generation", r(k.totalGenMWh, 1), "MWh/yr"],
    ["Load", r(k.loadMWh, 1), "MWh/yr"],
    ["Delivered by RE (net AC)", r(k.deliveredMWh, 1), "MWh/yr"],
    ["Unmet → diesel top-up", r(k.unmetMWh, 1), "MWh/yr"],
    ["Curtailed", r(k.curtailedMWh, 1), "MWh/yr"],
    ["LPSP", r(k.lpsp * 100, 2), "%"],
    ["Plant load factor (vs target)", r(k.plf * 100, 2), "%"],
    ["CAPEX", r(k.capexINR.total / 1e7, 2), "INR crore"],
    ["O&M", r(k.opexINRyr / 1e7, 3), "INR crore/yr"],
    ["LCOE (RE delivered)", r(k.lcoeRE, 2), "INR/kWh"],
    ["System cost incl. diesel top-up", r(k.systemCOE, 2), "INR/kWh"],
    ["CO2 avoided", r(k.co2AvoidedT, 0), "tCO2/yr"],
    ["Diesel avoided", r(k.dieselAvoidedKL, 0), "kL/yr"],
    ["Carbon credit value", r(k.carbonCreditINRyr / 1e5, 1), "INR lakh/yr"],
  ].forEach((l) => lines.push(row(l)));
  lines.push("");
  lines.push(row(["Month", "Wind MWh", "Floating solar MWh", "OTEC MWh", "Wave MWh", "Diesel top-up MWh", "Load MWh", "Delivered MWh", "Curtailed MWh", "Coverage %"]));
  (k.monthly ?? []).forEach((m) =>
    lines.push(row([m.month, r(m.wind, 1), r(m.fpv, 1), r(m.otec, 1), r(m.wave, 1), r(m.diesel, 1), r(m.load, 1), r(m.delivered, 1), r(m.curtailed, 1), r(m.coverage * 100, 1)]))
  );
  lines.push("");
  lines.push(row(["Technology", "Annual CF %", "Resource", "CAPEX", "Reliability", "Sustainability", "Weighted"]));
  x.tech.forEach((t) => lines.push(row([t.label, r(t.annualCF * 100, 1), r(t.resource, 1), r(t.capex, 1), r(t.reliability, 1), r(t.sustainability, 1), r(t.weighted, 2)])));
  lines.push("");
  lines.push(row(["Rank", "Wind kW", "Floating solar kWp", "OTEC kW", "Wave kW", "BESS kWh", "LCOE INR/kWh", "System cost INR/kWh", "CAPEX INR Cr", "LPSP %", "PLF %", "CO2 avoided t/yr", "Weighted score", "Meets target"]));
  x.ranked.slice(0, 50).forEach((cnd) =>
    lines.push(
      row([cnd.rank, cnd.config.wind, cnd.config.fpv, cnd.config.otec, cnd.config.wave, cnd.config.bess, r(cnd.lcoeRE), r(cnd.systemCOE), r(cnd.capexINR.total / 1e7), r(cnd.lpsp * 100), r(cnd.plf * 100), r(cnd.co2AvoidedT, 0), r(cnd.scores.weighted), cnd.feasible ? "yes" : "no"])
    )
  );
  lines.push("");
  lines.push(row(["Assumption", "Value"]));
  const a = x.assumptions;
  [
    ["Discount rate (real)", a.discountRate],
    ["Project life (yr)", a.lifeYr],
    ["FX INR/USD", a.fx],
    ["Diesel price INR/L", a.dieselPrice],
    ["Diesel SFC L/kWh", a.dieselSfc],
    ["Diesel emission factor tCO2/MWh", r(dieselEF(a), 3)],
    ["Carbon price USD/t", a.carbonPriceUsd],
    ["LPSP target", a.lpspTarget],
    ...GEN_KEYS.map((g) => [`${TECH_LABEL[g]} CAPEX INR/kW`, a.capex[g]]),
    ["BESS CAPEX INR/kWh", a.capex.bess],
  ].forEach((l) => lines.push(row(l)));
  return lines.join("\n");
}

export function downloadBlob(content: Blob, filename: string) {
  const url = URL.createObjectURL(content);
  const aEl = document.createElement("a");
  aEl.href = url;
  aEl.download = filename;
  document.body.appendChild(aEl);
  aEl.click();
  aEl.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export async function buildPDF(x: ExportInput): Promise<Blob> {
  const { jsPDF } = await import("jspdf");
  const autoTable = (await import("jspdf-autotable")).default;
  const doc = new jsPDF({ unit: "pt", format: "a4" });
  const ink: [number, number, number] = [15, 42, 51];
  const magenta: [number, number, number] = [176, 18, 127];
  const k = x.result;
  const c = k.config;

  doc.setTextColor(...ink);
  doc.setFont("helvetica", "bold").setFontSize(18).text("BlueGrid – island microgrid summary", 40, 50);
  doc.setFont("helvetica", "normal").setFontSize(10);
  doc.text(`${x.siteName}  ·  ${x.lat.toFixed(4)}°N ${x.lon.toFixed(4)}°E  ·  resource data: ${x.site.island.name} (${x.distanceKm.toFixed(1)} km)`, 40, 68);
  doc.text(`Load target ${x.load.kw} kW (${x.load.profile === "flat" ? "flat" : "island profile"})  ·  generated ${new Date().toLocaleDateString("en-IN")}`, 40, 82);
  doc.setTextColor(...magenta).setFontSize(9).text("Dummy dataset – replace with NIOT / GSA data before planning decisions.", 40, 96);
  doc.setTextColor(...ink);

  const head = { fillColor: ink, textColor: 255, fontStyle: "bold" as const };
  autoTable(doc, {
    startY: 110,
    head: [["Configuration", "Wind kW", "Floating solar kWp", "OTEC kW", "Wave kW", "BESS kWh"]],
    body: [["Selected", c.wind, c.fpv, c.otec, c.wave, c.bess]],
    headStyles: head,
    styles: { fontSize: 9 },
  });
  autoTable(doc, {
    head: [["Result", "Value"]],
    body: [
      ["RE energy delivered (net AC)", `${k.deliveredMWh.toFixed(0)} MWh/yr`],
      ["Plant load factor vs target", `${(k.plf * 100).toFixed(1)} %`],
      ["Loss of power supply (LPSP)", `${(k.lpsp * 100).toFixed(2)} %  (${k.unmetHours} h)`],
      ["LCOE (RE delivered)", `INR ${k.lcoeRE.toFixed(2)}/kWh`],
      ["System cost incl. diesel top-up", `INR ${k.systemCOE.toFixed(2)}/kWh`],
      ["CAPEX", `INR ${(k.capexINR.total / 1e7).toFixed(2)} crore`],
      ["CO2 avoided", `${k.co2AvoidedT.toFixed(0)} t/yr`],
      ["Carbon credit value", `INR ${(k.carbonCreditINRyr / 1e5).toFixed(1)} lakh/yr`],
    ],
    headStyles: head,
    styles: { fontSize: 9 },
    columnStyles: { 0: { cellWidth: 220 } },
  });
  autoTable(doc, {
    head: [["Month", "Wind", "Solar", "OTEC", "Wave", "Diesel", "Load", "Coverage"]],
    body: (k.monthly ?? []).map((m) => [m.month, m.wind.toFixed(0), m.fpv.toFixed(0), m.otec.toFixed(0), m.wave.toFixed(0), m.diesel.toFixed(0), m.load.toFixed(0), `${(m.coverage * 100).toFixed(1)}%`]),
    headStyles: head,
    styles: { fontSize: 8 },
    didDrawPage: () => undefined,
  });
  autoTable(doc, {
    head: [["Technology", "Annual CF", "Resource", "CAPEX", "Reliability", "Sustain.", "Weighted"]],
    body: x.tech.map((t) => [t.label, `${(t.annualCF * 100).toFixed(1)}%`, t.resource.toFixed(1), t.capex.toFixed(1), t.reliability.toFixed(1), t.sustainability.toFixed(1), t.weighted.toFixed(2)]),
    headStyles: head,
    styles: { fontSize: 8 },
  });
  autoTable(doc, {
    head: [["#", "Wind", "Solar", "OTEC", "Wave", "BESS kWh", "LCOE ₹", "CAPEX Cr", "LPSP", "Score"]].map((h) => h.map((s) => s.replace("₹", "INR"))),
    body: x.ranked.slice(0, 15).map((cnd) => [
      cnd.rank ?? "",
      cnd.config.wind,
      cnd.config.fpv,
      cnd.config.otec,
      cnd.config.wave,
      cnd.config.bess,
      cnd.lcoeRE.toFixed(2),
      (cnd.capexINR.total / 1e7).toFixed(1),
      `${(cnd.lpsp * 100).toFixed(1)}%`,
      cnd.scores.weighted.toFixed(2),
    ]),
    headStyles: head,
    styles: { fontSize: 8 },
  });
  return doc.output("blob");
}
