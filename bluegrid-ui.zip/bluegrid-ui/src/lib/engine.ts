// BlueGrid calculation engine: site data, hourly dispatch with BESS, economics, scoring, optimizer.
import islandsJson from "@/data/islands.json";
import monthlyJson from "@/data/monthly.json";
import hourlyJson from "@/data/hourlyRef.json";
import paramsJson from "@/data/params.json";

export const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
export const HOURS_PER_YEAR = 8760;

export type GenKey = "wind" | "fpv" | "otec" | "wave";
export const GEN_KEYS: GenKey[] = ["wind", "fpv", "otec", "wave"];
export const TECH_LABEL: Record<GenKey | "bess" | "diesel", string> = {
  wind: "Wind",
  fpv: "Floating solar",
  otec: "OTEC",
  wave: "Wave",
  bess: "Battery (BESS)",
  diesel: "Diesel top-up",
};

export interface Island {
  name: string;
  group: string;
  atoll: string;
  inhabited: boolean;
  lat: number;
  lon: number;
  landKm2: number;
  landSrc: string;
  lagoonKm2: number;
  lagoonSrc: string;
  population: number;
  distTo1000mKm: number;
  peakDemandKw: number;
}

export interface MonthlySeries {
  hours: number[];
  ws80: number[];
  windCF: number[];
  windPD: number[];
  ghi: number[];
  pvoutMonth: number[];
  fpvCF: number[];
  tAmb: number[];
  sst: number[];
  t1000: number[];
  dT: number[];
  otecCF: number[];
  waveP: number[];
  hs: number[];
  waveCF: number[];
}

export const ISLANDS = islandsJson as Island[];
const MONTHLY = monthlyJson as Record<string, MonthlySeries>;
const HOURLY = hourlyJson as {
  island: string;
  month: number[];
  cfWind: number[];
  cfFpv: number[];
  cfOtec: number[];
  cfWave: number[];
  loadShape: number[];
};
const PARAMS = paramsJson as {
  tech: Record<GenKey | "bess" | "diesel", { label: string; unit: string; capexIsland: number; opexPerUnitYr: number; lifetimeYr: number; lcaG: number | null; trl: number | null; capexSource: string }>;
  finance: Record<string, number>;
};
export const TECH_PARAMS = PARAMS.tech;

// ------------------------------------------------------------------ assumptions
export interface Assumptions {
  discountRate: number;
  lifeYr: number;
  fx: number;
  dieselPrice: number; // INR/L
  dieselSfc: number; // L/kWh
  dieselCo2PerL: number; // kg/L
  carbonPriceUsd: number; // USD/t
  bessRte: number;
  bessDod: number;
  bessCRate: number;
  bessReplYear: number;
  bessReplFrac: number;
  applySubsidies: boolean;
  fpvCfaPerKw: number;
  bessVgfPerKwh: number;
  lpspTarget: number;
  capex: Record<GenKey | "bess", number>; // INR per kW (per kWh for BESS), island-delivered
  opex: Record<GenKey | "bess", number>; // INR per kW-yr (per kWh-yr for BESS)
}

const F = PARAMS.finance;
export const DEFAULT_ASSUMPTIONS: Assumptions = {
  discountRate: F.discount_rate_real,
  lifeYr: F.project_life_yr,
  fx: F.fx_INR_per_USD,
  dieselPrice: F.diesel_landed_price_INR_per_L,
  dieselSfc: F.diesel_sfc_L_per_kWh,
  dieselCo2PerL: F.diesel_co2_kg_per_L,
  carbonPriceUsd: F.carbon_price_USD_per_t,
  bessRte: F.bess_round_trip_eff,
  bessDod: F.bess_depth_of_discharge,
  bessCRate: F.bess_max_c_rate,
  bessReplYear: F.bess_replacement_year,
  bessReplFrac: F.bess_replacement_cost_fraction,
  applySubsidies: F.apply_subsidies_flag === 1,
  fpvCfaPerKw: F.fpv_cfa_subsidy_INR_per_kW,
  bessVgfPerKwh: F.bess_vgf_INR_per_kWh,
  lpspTarget: F.reliability_target_LPSP,
  capex: {
    wind: PARAMS.tech.wind.capexIsland,
    fpv: PARAMS.tech.fpv.capexIsland,
    otec: PARAMS.tech.otec.capexIsland,
    wave: PARAMS.tech.wave.capexIsland,
    bess: PARAMS.tech.bess.capexIsland,
  },
  opex: {
    wind: PARAMS.tech.wind.opexPerUnitYr,
    fpv: PARAMS.tech.fpv.opexPerUnitYr,
    otec: PARAMS.tech.otec.opexPerUnitYr,
    wave: PARAMS.tech.wave.opexPerUnitYr,
    bess: PARAMS.tech.bess.opexPerUnitYr,
  },
};

export const crf = (r: number, n: number) => (r === 0 ? 1 / n : (r * (1 + r) ** n) / ((1 + r) ** n - 1));
export const dieselEF = (a: Assumptions) => a.dieselSfc * a.dieselCo2PerL; // tCO2/MWh

// ------------------------------------------------------------------ site
const R_EARTH = 6371;
export function haversineKm(lat1: number, lon1: number, lat2: number, lon2: number) {
  const toR = Math.PI / 180;
  const dLat = (lat2 - lat1) * toR;
  const dLon = (lon2 - lon1) * toR;
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(lat1 * toR) * Math.cos(lat2 * toR) * Math.sin(dLon / 2) ** 2;
  return 2 * R_EARTH * Math.asin(Math.sqrt(a));
}

export function nearestIsland(lat: number, lon: number): { island: Island; distanceKm: number } {
  let best = ISLANDS[0];
  let bestD = Infinity;
  for (const isl of ISLANDS) {
    const d = haversineKm(lat, lon, isl.lat, isl.lon);
    if (d < bestD) {
      bestD = d;
      best = isl;
    }
  }
  return { island: best, distanceKm: bestD };
}

export interface SiteData {
  island: Island;
  monthly: MonthlySeries;
  hourly: { wind: Float32Array; fpv: Float32Array; otec: Float32Array; wave: Float32Array; loadShape: Float32Array; month: Uint8Array };
}

const siteCache = new Map<string, SiteData>();
const REF_MONTH_MEANS = (() => {
  const keys = ["cfWind", "cfFpv", "cfOtec", "cfWave"] as const;
  const out: Record<string, number[]> = {};
  for (const k of keys) {
    const sum = new Array(12).fill(0);
    const cnt = new Array(12).fill(0);
    HOURLY[k].forEach((v, i) => {
      sum[HOURLY.month[i]] += v;
      cnt[HOURLY.month[i]] += 1;
    });
    out[k] = sum.map((s, m) => s / cnt[m]);
  }
  return out;
})();

/** Hourly profiles for an island: the Kadmat synthetic year rescaled month-by-month to the island's monthly CFs. */
export function getSiteData(islandName: string): SiteData {
  const cached = siteCache.get(islandName);
  if (cached) return cached;
  const island = ISLANDS.find((i) => i.name === islandName) ?? ISLANDS[0];
  const monthly = MONTHLY[island.name];
  const n = HOURLY.month.length;
  const mk = (src: number[], ref: number[], target: number[], cap: number) => {
    const a = new Float32Array(n);
    for (let i = 0; i < n; i++) {
      const m = HOURLY.month[i];
      const k = ref[m] > 0 ? target[m] / ref[m] : 0;
      a[i] = Math.min(src[i] * k, cap);
    }
    return a;
  };
  const data: SiteData = {
    island,
    monthly,
    hourly: {
      wind: mk(HOURLY.cfWind, REF_MONTH_MEANS.cfWind, monthly.windCF, 0.9),
      fpv: mk(HOURLY.cfFpv, REF_MONTH_MEANS.cfFpv, monthly.fpvCF, 0.95),
      otec: mk(HOURLY.cfOtec, REF_MONTH_MEANS.cfOtec, monthly.otecCF, 1.05),
      wave: mk(HOURLY.cfWave, REF_MONTH_MEANS.cfWave, monthly.waveCF, 0.9),
      loadShape: Float32Array.from(HOURLY.loadShape),
      month: Uint8Array.from(HOURLY.month),
    },
  };
  siteCache.set(islandName, data);
  return data;
}

// ------------------------------------------------------------------ simulation
export interface Config {
  wind: number;
  fpv: number;
  otec: number;
  wave: number;
  bess: number;
}
export type LoadProfile = "flat" | "island";
export interface LoadSpec {
  kw: number;
  profile: LoadProfile;
}

export interface MonthRow {
  month: string;
  wind: number;
  fpv: number;
  otec: number;
  wave: number;
  diesel: number;
  load: number;
  delivered: number;
  curtailed: number;
  coverage: number;
}

export interface SimResult {
  config: Config;
  genMWh: Record<GenKey, number>;
  totalGenMWh: number;
  loadMWh: number;
  deliveredMWh: number;
  unmetMWh: number;
  curtailedMWh: number;
  bessThroughputMWh: number;
  lpsp: number;
  unmetHours: number;
  plf: number;
  reFraction: number;
  monthly: MonthRow[] | null;
  capexINR: Record<GenKey | "bess", number> & { subsidy: number; total: number };
  opexINRyr: number;
  bessReplPV: number;
  annualisedCapitalINR: number;
  dieselFuelINRyr: number;
  lcoeRE: number; // INR/kWh of RE energy delivered
  systemCOE: number; // INR/kWh of load incl. diesel top-up fuel
  co2AvoidedT: number;
  dieselAvoidedKL: number;
  carbonCreditINRyr: number;
  freshwaterM3day: number;
}

export function simulate(site: SiteData, cfg: Config, load: LoadSpec, a: Assumptions, detail = true): SimResult {
  const h = site.hourly;
  const n = h.wind.length;
  const E = cfg.bess;
  const eMin = (1 - a.bessDod) * E;
  const pMax = a.bessCRate * E;
  const eta = Math.sqrt(a.bessRte);
  let soc = E > 0 ? 0.5 * (E + eMin) : 0;

  let gW = 0, gS = 0, gO = 0, gV = 0, Ltot = 0, unmet = 0, curt = 0, thr = 0, unmetHours = 0;
  const mon = detail
    ? Array.from({ length: 12 }, () => ({ wind: 0, fpv: 0, otec: 0, wave: 0, diesel: 0, load: 0, delivered: 0, curtailed: 0 }))
    : null;
  const flat = load.profile === "flat";

  for (let t = 0; t < n; t++) {
    const w = cfg.wind * h.wind[t];
    const s = cfg.fpv * h.fpv[t];
    const o = cfg.otec * h.otec[t];
    const v = cfg.wave * h.wave[t];
    const gen = w + s + o + v;
    const L = flat ? load.kw : load.kw * h.loadShape[t];
    let u = 0;
    let c = 0;
    if (gen >= L) {
      const surplus = gen - L;
      let ch = 0;
      if (E > 0) {
        ch = Math.min(surplus, pMax, (E - soc) / eta);
        if (ch < 0) ch = 0;
        soc += ch * eta;
        thr += ch;
      }
      c = surplus - ch;
    } else {
      const def = L - gen;
      let dis = 0;
      if (E > 0) {
        dis = Math.min(def, pMax, (soc - eMin) * eta);
        if (dis < 0) dis = 0;
        soc -= dis / eta;
      }
      u = def - dis;
      if (u > 1e-6) unmetHours++;
    }
    gW += w; gS += s; gO += o; gV += v; Ltot += L; unmet += u; curt += c;
    if (mon) {
      const m = mon[h.month[t]];
      m.wind += w; m.fpv += s; m.otec += o; m.wave += v; m.diesel += u; m.load += L; m.delivered += L - u; m.curtailed += c;
    }
  }

  const loadMWh = Ltot / 1000;
  const unmetMWh = unmet / 1000;
  const deliveredMWh = loadMWh - unmetMWh;

  // economics
  const cap = {
    wind: cfg.wind * a.capex.wind,
    fpv: cfg.fpv * a.capex.fpv,
    otec: cfg.otec * a.capex.otec,
    wave: cfg.wave * a.capex.wave,
    bess: cfg.bess * a.capex.bess,
  };
  const subsidy = a.applySubsidies ? cfg.fpv * a.fpvCfaPerKw + cfg.bess * a.bessVgfPerKwh : 0;
  const capTotal = cap.wind + cap.fpv + cap.otec + cap.wave + cap.bess - subsidy;
  const opex = cfg.wind * a.opex.wind + cfg.fpv * a.opex.fpv + cfg.otec * a.opex.otec + cfg.wave * a.opex.wave + cfg.bess * a.opex.bess;
  const replPV = a.bessReplYear < a.lifeYr ? (cap.bess * a.bessReplFrac) / (1 + a.discountRate) ** a.bessReplYear : 0;
  const ann = (capTotal + replPV) * crf(a.discountRate, a.lifeYr);
  const dieselFuel = unmet * a.dieselSfc * a.dieselPrice;
  const ef = dieselEF(a);
  const co2 = deliveredMWh * ef;

  return {
    config: cfg,
    genMWh: { wind: gW / 1000, fpv: gS / 1000, otec: gO / 1000, wave: gV / 1000 },
    totalGenMWh: (gW + gS + gO + gV) / 1000,
    loadMWh,
    deliveredMWh,
    unmetMWh,
    curtailedMWh: curt / 1000,
    bessThroughputMWh: thr / 1000,
    lpsp: loadMWh > 0 ? unmetMWh / loadMWh : 0,
    unmetHours,
    plf: deliveredMWh / ((load.kw * n) / 1000),
    reFraction: loadMWh > 0 ? deliveredMWh / loadMWh : 0,
    monthly: mon
      ? mon.map((m, i) => ({
          month: MONTHS[i],
          wind: m.wind / 1000,
          fpv: m.fpv / 1000,
          otec: m.otec / 1000,
          wave: m.wave / 1000,
          diesel: m.diesel / 1000,
          load: m.load / 1000,
          delivered: m.delivered / 1000,
          curtailed: m.curtailed / 1000,
          coverage: m.load > 0 ? m.delivered / m.load : 0,
        }))
      : null,
    capexINR: { ...cap, subsidy, total: capTotal },
    opexINRyr: opex,
    bessReplPV: replPV,
    annualisedCapitalINR: ann,
    dieselFuelINRyr: dieselFuel,
    lcoeRE: deliveredMWh > 0 ? (ann + opex) / (deliveredMWh * 1000) : 0,
    systemCOE: loadMWh > 0 ? (ann + opex + dieselFuel) / (loadMWh * 1000) : 0,
    co2AvoidedT: co2,
    dieselAvoidedKL: deliveredMWh * a.dieselSfc,
    carbonCreditINRyr: co2 * a.carbonPriceUsd * a.fx,
    freshwaterM3day: cfg.otec * F.otec_freshwater_m3_day_per_kW,
  };
}

// ------------------------------------------------------------------ technology scoring
export interface Weights {
  resource: number;
  capex: number;
  reliability: number;
  sustainability: number;
}
export const DEFAULT_WEIGHTS: Weights = { resource: 0.3, capex: 0.25, reliability: 0.25, sustainability: 0.2 };
export const CRITERIA: { key: keyof Weights; label: string }[] = [
  { key: "resource", label: "Resource potential" },
  { key: "capex", label: "CAPEX" },
  { key: "reliability", label: "Reliability" },
  { key: "sustainability", label: "Sustainability" },
];

const TRL: Record<GenKey, number> = { wind: 9, fpv: 7, otec: 6, wave: 6 };
const LCA: Record<GenKey, number> = { wind: 11, fpv: 48, otec: 15, wave: 20 };

export interface TechScore {
  key: GenKey;
  label: string;
  annualCF: number;
  minMonthCF: number;
  firmness: number;
  capexPerKw: number;
  lcaG: number;
  resource: number;
  capex: number;
  reliability: number;
  sustainability: number;
  weighted: number;
}

export function techScores(site: SiteData, a: Assumptions, w: Weights): TechScore[] {
  const m = site.monthly;
  const hrs = m.hours.reduce((x, y) => x + y, 0);
  const cfOf = (k: GenKey) => (k === "wind" ? m.windCF : k === "fpv" ? m.fpvCF : k === "otec" ? m.otecCF : m.waveCF);
  const base = GEN_KEYS.map((k) => {
    const cf = cfOf(k);
    const annual = cf.reduce((s, v, i) => s + v * m.hours[i], 0) / hrs;
    const minM = Math.min(...cf);
    return { key: k, annual, minM, firm: annual > 0 ? minM / annual : 0 };
  });
  const maxCF = Math.max(...base.map((b) => b.annual));
  const minCapex = Math.min(...GEN_KEYS.map((k) => a.capex[k]));
  const wsum = w.resource + w.capex + w.reliability + w.sustainability || 1;
  return base.map((b) => {
    const resource = (10 * b.annual) / maxCF;
    const capex = (10 * minCapex) / a.capex[b.key];
    const reliability = 10 * (0.7 * b.firm + 0.3 * (TRL[b.key] / 9));
    const sustainability = Math.min(10, 10 * (1 - LCA[b.key] / 100) + (b.key === "otec" ? 0.5 : 0));
    const weighted = (w.resource * resource + w.capex * capex + w.reliability * reliability + w.sustainability * sustainability) / wsum;
    return {
      key: b.key,
      label: TECH_LABEL[b.key],
      annualCF: b.annual,
      minMonthCF: b.minM,
      firmness: b.firm,
      capexPerKw: a.capex[b.key],
      lcaG: LCA[b.key],
      resource,
      capex,
      reliability,
      sustainability,
      weighted,
    };
  });
}

// ------------------------------------------------------------------ configuration scoring + ranking
export interface Candidate extends Omit<SimResult, "monthly"> {
  id: string;
  feasible: boolean;
  scores: { resource: number; capex: number; reliability: number; sustainability: number; weighted: number };
  rank?: number;
}

export function scoreCandidates(results: SimResult[], tech: TechScore[], a: Assumptions, w: Weights): Candidate[] {
  const res = Object.fromEntries(tech.map((t) => [t.key, t.resource])) as Record<GenKey, number>;
  const feasible = results.filter((r) => r.lpsp <= a.lpspTarget && r.capexINR.total > 0);
  const capexRef = feasible.length ? Math.min(...feasible.map((r) => r.capexINR.total)) : Math.min(...results.filter((r) => r.capexINR.total > 0).map((r) => r.capexINR.total));
  const wsum = w.resource + w.capex + w.reliability + w.sustainability || 1;
  return results.map((r) => {
    const g = r.totalGenMWh;
    const resource = g > 0 ? GEN_KEYS.reduce((s, k) => s + r.genMWh[k] * res[k], 0) / g : 0;
    const capex = r.capexINR.total > 0 ? Math.min(10, (10 * capexRef) / r.capexINR.total) : 0;
    const reliability = 10 * Math.max(0, 1 - r.lpsp / 0.25);
    const avgLca = g > 0 ? GEN_KEYS.reduce((s, k) => s + r.genMWh[k] * LCA[k], 0) / g : 0;
    const sustainability = 10 * r.reFraction * (1 - avgLca / 1000);
    const weighted = (w.resource * resource + w.capex * capex + w.reliability * reliability + w.sustainability * sustainability) / wsum;
    const c = r.config;
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const { monthly: _m, ...rest } = r;
    return {
      ...rest,
      id: `${c.wind}-${c.fpv}-${c.otec}-${c.wave}-${c.bess}`,
      feasible: r.lpsp <= a.lpspTarget,
      scores: { resource, capex, reliability, sustainability, weighted },
    };
  });
}

export type RankMode = "cost" | "score";
export function rankCandidates(cands: Candidate[], mode: RankMode): Candidate[] {
  const sorted = [...cands].sort((x, y) => {
    if (mode === "score") return y.scores.weighted - x.scores.weighted;
    if (x.feasible !== y.feasible) return x.feasible ? -1 : 1;
    if (x.feasible) return x.lcoeRE - y.lcoeRE;
    return x.lpsp - y.lpsp;
  });
  return sorted.map((c, i) => ({ ...c, rank: i + 1 }));
}

// ------------------------------------------------------------------ optimizer (grid search)
export interface SearchSpace {
  wind: number[];
  fpv: number[];
  otec: number[];
  wave: number[];
  bess: number[];
}
const range = (max: number, step: number) => Array.from({ length: Math.floor(max / step) + 1 }, (_, i) => i * step);
export const DEFAULT_SPACE: SearchSpace = {
  wind: range(4000, 500),
  fpv: range(8000, 1000),
  otec: range(1000, 250),
  wave: range(1000, 500),
  bess: range(24000, 4000),
};
export const spaceSize = (s: SearchSpace) => s.wind.length * s.fpv.length * s.otec.length * s.wave.length * s.bess.length;

/** Runs every configuration in the space; yields to the UI between chunks. */
export async function runSearch(
  site: SiteData,
  load: LoadSpec,
  a: Assumptions,
  space: SearchSpace = DEFAULT_SPACE,
  onProgress?: (done: number, total: number) => void,
  signal?: { cancelled: boolean }
): Promise<SimResult[]> {
  const cfgs: Config[] = [];
  for (const wind of space.wind)
    for (const fpv of space.fpv)
      for (const otec of space.otec)
        for (const wave of space.wave)
          for (const bess of space.bess) if (wind + fpv + otec + wave > 0) cfgs.push({ wind, fpv, otec, wave, bess });
  const out: SimResult[] = [];
  const chunk = 400;
  for (let i = 0; i < cfgs.length; i += chunk) {
    if (signal?.cancelled) break;
    for (let j = i; j < Math.min(i + chunk, cfgs.length); j++) out.push(simulate(site, cfgs[j], load, a, false));
    onProgress?.(Math.min(i + chunk, cfgs.length), cfgs.length);
    await new Promise((r) => setTimeout(r, 0));
  }
  return out;
}
