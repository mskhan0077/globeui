const nf = (d: number) => new Intl.NumberFormat("en-IN", { maximumFractionDigits: d, minimumFractionDigits: d });
export const fmt = (v: number, d = 0) => (Number.isFinite(v) ? nf(d).format(v) : "–");
export const fmtPct = (v: number, d = 1) => (Number.isFinite(v) ? `${nf(d).format(v * 100)}%` : "–");
/** INR → crore (1 Cr = 10^7) */
export const fmtCr = (inr: number, d = 2) => `₹${fmt(inr / 1e7, d)} Cr`;
/** INR → lakh (1 L = 10^5) */
export const fmtLakh = (inr: number, d = 1) => `₹${fmt(inr / 1e5, d)} L`;
export const fmtINR = (v: number, d = 2) => `₹${fmt(v, d)}`;
export const fmtKw = (kw: number) => (kw >= 1000 ? `${fmt(kw / 1000, kw % 1000 === 0 ? 0 : 2)} MW` : `${fmt(kw)} kW`);
export const fmtKwh = (kwh: number) => (kwh >= 1000 ? `${fmt(kwh / 1000, kwh % 1000 === 0 ? 0 : 1)} MWh` : `${fmt(kwh)} kWh`);
export const fmtCoord = (v: number, pos: string, neg: string) => `${Math.abs(v).toFixed(4)}° ${v >= 0 ? pos : neg}`;
