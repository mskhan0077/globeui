import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Layers, Maximize2, Moon, Sun, SunMoon, Waves } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { SiteMap, type Basemap } from "@/components/SiteMap";
import { SitePanel, type SiteState } from "@/components/SitePanel";
import { ResourceStrip } from "@/components/ResourceStrip";
import { ConfigPanel } from "@/components/ConfigPanel";
import { ResultsPanel } from "@/components/ResultsPanel";
import { Recommendations } from "@/components/Recommendations";
import { TechScoring } from "@/components/TechScoring";
import { AssumptionsPanel } from "@/components/AssumptionsPanel";
import { SiteDataPanel } from "@/components/SiteDataPanel";
import { ExportDialog } from "@/components/ExportDialog";
import {
  DEFAULT_ASSUMPTIONS,
  DEFAULT_SPACE,
  DEFAULT_WEIGHTS,
  ISLANDS,
  getSiteData,
  nearestIsland,
  rankCandidates,
  runSearch,
  scoreCandidates,
  simulate,
  spaceSize,
  techScores,
  type Assumptions,
  type Config,
  type LoadSpec,
  type RankMode,
  type SimResult,
  type Weights,
} from "@/lib/engine";

const START_ISLAND = ISLANDS.find((i) => i.name === "Kadmat")!;
const START_CONFIG: Config = { wind: 1500, fpv: 1500, otec: 500, wave: 0, bess: 4000 };
const cfgId = (c: Config) => `${c.wind}-${c.fpv}-${c.otec}-${c.wave}-${c.bess}`;

type ThemeMode = "system" | "light" | "dark";
function useTheme(): [ThemeMode, () => void] {
  const [mode, setMode] = useState<ThemeMode>(() => {
    try {
      return (localStorage.getItem("bluegrid-theme") as ThemeMode) || "system";
    } catch {
      return "system";
    }
  });
  useEffect(() => {
    const root = document.documentElement;
    if (mode === "system") root.removeAttribute("data-theme");
    else root.setAttribute("data-theme", mode);
    try {
      localStorage.setItem("bluegrid-theme", mode);
    } catch {
      /* storage unavailable */
    }
  }, [mode]);
  const cycle = () => setMode((m) => (m === "system" ? "light" : m === "light" ? "dark" : "system"));
  return [mode, cycle];
}

export default function App() {
  const [theme, cycleTheme] = useTheme();
  const [site, setSite] = useState<SiteState>({ name: START_ISLAND.name, lat: START_ISLAND.lat, lon: START_ISLAND.lon, islandName: START_ISLAND.name });
  const [load, setLoad] = useState<LoadSpec>({ kw: 1000, profile: "flat" });
  const [config, setConfig] = useState<Config>(START_CONFIG);
  const [assumptions, setAssumptions] = useState<Assumptions>(DEFAULT_ASSUMPTIONS);
  const [weights, setWeights] = useState<Weights>(DEFAULT_WEIGHTS);
  const [rankMode, setRankMode] = useState<RankMode>("cost");
  const [basemap, setBasemap] = useState<Basemap>("ocean");
  const [tileNote, setTileNote] = useState(false);
  const [focusKey, setFocusKey] = useState(0);
  const [fitKey, setFitKey] = useState(0);
  const [tab, setTab] = useState("ranking");

  // ---- site → dataset island
  const nearest = useMemo(() => {
    if (site.islandName) return { island: ISLANDS.find((i) => i.name === site.islandName)!, distanceKm: 0 };
    return nearestIsland(site.lat, site.lon);
  }, [site.islandName, site.lat, site.lon]);
  const siteData = useMemo(() => getSiteData(nearest.island.name), [nearest.island.name]);

  // ---- current mix
  const result: SimResult = useMemo(() => simulate(siteData, config, load, assumptions, true), [siteData, config, load, assumptions]);
  const tech = useMemo(() => techScores(siteData, assumptions, weights), [siteData, assumptions, weights]);

  // ---- grid search (re-runs when anything that changes the physics or cost changes)
  const [search, setSearch] = useState<{ status: "idle" | "running" | "done"; progress: number; results: SimResult[] }>({ status: "idle", progress: 0, results: [] });
  const touched = useRef(false);
  const token = useRef({ cancelled: false });
  const searchKey = useMemo(() => {
    const { lpspTarget: _ignored, ...rest } = assumptions;
    void _ignored;
    return JSON.stringify([nearest.island.name, load, rest]);
  }, [nearest.island.name, load, assumptions]);
  const total = spaceSize(DEFAULT_SPACE);

  const startSearch = useCallback(() => {
    token.current.cancelled = true;
    const t = { cancelled: false };
    token.current = t;
    setSearch((s) => ({ ...s, status: "running", progress: 0 }));
    runSearch(siteData, load, assumptions, DEFAULT_SPACE, (done) => !t.cancelled && setSearch((s) => ({ ...s, progress: done })), t).then((results) => {
      if (t.cancelled) return;
      setSearch({ status: "done", progress: results.length, results });
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchKey]);

  useEffect(() => {
    const id = setTimeout(startSearch, 350);
    return () => clearTimeout(id);
  }, [startSearch]);

  const ranked = useMemo(
    () => (search.results.length ? rankCandidates(scoreCandidates(search.results, tech, assumptions, weights), rankMode) : []),
    [search.results, tech, assumptions, weights, rankMode]
  );
  const best = useMemo(() => {
    if (!ranked.length) return null;
    return rankMode === "cost" ? ranked[0] : rankCandidates(ranked, "cost")[0];
  }, [ranked, rankMode]);

  // first result for a new site: load the lowest-cost mix unless the user has been moving sliders
  useEffect(() => {
    if (search.status === "done" && best && !touched.current) setConfig(best.config);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search.status, search.results]);

  const currentId = cfgId(config);
  const matchRank = ranked.find((c) => c.id === currentId)?.rank ?? null;

  // ---- handlers
  const selectIsland = (name: string) => {
    const isl = ISLANDS.find((i) => i.name === name)!;
    touched.current = false;
    setSite({ name: isl.name, lat: isl.lat, lon: isl.lon, islandName: isl.name });
    setFocusKey((k) => k + 1);
  };
  const pickPoint = (lat: number, lon: number) => {
    touched.current = false;
    setSite((s) => ({ name: s.islandName ? "Custom site" : s.name, lat, lon, islandName: null }));
  };
  const changeSite = (s: SiteState) => {
    const moved = s.lat !== site.lat || s.lon !== site.lon;
    setSite(s);
    if (moved) {
      touched.current = false;
      setFocusKey((k) => k + 1);
    }
  };
  const changeConfig = (c: Config) => {
    touched.current = true;
    setConfig(c);
  };

  const exportInput = useMemo(
    () => ({ siteName: site.name || nearest.island.name, lat: site.lat, lon: site.lon, site: siteData, distanceKm: nearest.distanceKm, load, assumptions, result, ranked, tech }),
    [site, nearest, siteData, load, assumptions, result, ranked, tech]
  );

  const ThemeIcon = theme === "light" ? Sun : theme === "dark" ? Moon : SunMoon;

  return (
    <div className="min-h-full">
      <header className="sticky top-[env(safe-area-inset-top,0px)] z-[1000] border-b bg-background/90 backdrop-blur">
        <div className="mx-auto flex max-w-[1440px] flex-wrap items-center gap-x-4 gap-y-2 px-4 py-3 sm:px-6">
          <div className="flex items-center gap-2.5">
            <span className="grid size-8 place-items-center rounded-md bg-primary text-primary-foreground">
              <Waves className="size-4" aria-hidden />
            </span>
            <div className="leading-tight">
              <h1 className="text-lg font-extrabold [font-stretch:80%]">BlueGrid</h1>
              <p className="text-xs text-muted-foreground">Hybrid renewable planner for Lakshadweep island microgrids</p>
            </div>
          </div>
          <Badge variant="warn" className="hidden sm:inline-flex">
            Dummy dataset · 36 islands
          </Badge>
          <div className="ml-auto flex items-center gap-2">
            <ExportDialog input={exportInput} />
            <Button variant="ghost" size="icon" onClick={cycleTheme} aria-label={`Theme: ${theme}. Switch theme`} title={`Theme: ${theme}`}>
              <ThemeIcon aria-hidden />
            </Button>
          </div>
        </div>
      </header>

      <main className="mx-auto flex max-w-[1440px] flex-col gap-6 px-4 py-5 sm:px-6">
        {/* ---------------- top: chart + site inputs ---------------- */}
        <section className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_380px]" aria-label="Site selection">
          <Card className="gap-0 overflow-hidden py-0">
            <div className="flex flex-wrap items-center gap-2 border-b px-4 py-2.5">
              <div className="mr-auto">
                <h2 className="text-base font-bold">Sea chart · Lakshadweep</h2>
                <p className="text-xs text-muted-foreground">Click an island, or anywhere on the water to plan a custom site.</p>
              </div>
              <Select
                value={basemap}
                onValueChange={(v) => {
                  setTileNote(false);
                  setBasemap(v as Basemap);
                }}
              >
                <SelectTrigger className="h-8 w-48" aria-label="Basemap">
                  <Layers className="size-4 opacity-60" aria-hidden />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ocean">Ocean bathymetry</SelectItem>
                  <SelectItem value="chart">Sea chart (offline)</SelectItem>
                  <SelectItem value="osm">OpenStreetMap</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline" size="sm" onClick={() => setFitKey((k) => k + 1)}>
                <Maximize2 aria-hidden /> All islands
              </Button>
            </div>
            <div className="relative min-h-[340px] flex-1 sm:min-h-[480px]">
              <SiteMap
                islands={ISLANDS}
                selectedIsland={nearest.island.name}
                point={[site.lat, site.lon]}
                isCustom={site.islandName === null}
                basemap={basemap}
                onTileError={() => {
                  setBasemap("chart");
                  setTileNote(true);
                }}
                onSelectIsland={selectIsland}
                onPick={pickPoint}
                focusKey={focusKey}
                fitKey={fitKey}
              />
              <div className="pointer-events-none absolute bottom-3 left-3 z-[500] flex flex-col gap-1 rounded-md border bg-card/90 px-2.5 py-2 text-[11px] backdrop-blur">
                <span className="flex items-center gap-2">
                  <span className="size-2.5 rounded-full bg-foreground ring-2 ring-card" /> Inhabited island
                </span>
                <span className="flex items-center gap-2">
                  <span className="size-2 rounded-full border-[1.5px] border-foreground bg-card" /> Uninhabited islet
                </span>
                <span className="flex items-center gap-2">
                  <span className="size-3 rounded-full border-2 border-magenta" /> Selected site
                </span>
                <span className="flex items-center gap-2">
                  <span className="size-3 rounded-full bg-[var(--sea-shallow)]" /> Atoll lagoon (to scale)
                </span>
              </div>
              {tileNote && (
                <div className="absolute top-3 right-3 z-[500] max-w-64 rounded-md border bg-card/95 px-2.5 py-1.5 text-[11px] text-muted-foreground">
                  Online basemap tiles could not load here, so the offline sea chart is shown.
                </div>
              )}
            </div>
          </Card>
          <SitePanel
            islands={ISLANDS}
            site={site}
            dataIsland={nearest.island}
            distanceKm={nearest.distanceKm}
            load={load}
            onSelectIsland={selectIsland}
            onSiteChange={changeSite}
            onLoadChange={setLoad}
          />
        </section>

        <ResourceStrip m={siteData.monthly} islandName={site.islandName ? site.name : `${site.name} (data: ${nearest.island.name})`} />

        <section className="grid gap-4 xl:grid-cols-[380px_minmax(0,1fr)]" aria-label="Configuration and results">
          <ConfigPanel
            config={config}
            onChange={changeConfig}
            assumptions={assumptions}
            tech={tech}
            best={best}
            matchRank={matchRank}
            onApplyBest={() => best && setConfig(best.config)}
            onReset={() => changeConfig(START_CONFIG)}
          />
          <ResultsPanel r={result} a={assumptions} targetKw={load.kw} />
        </section>

        <Tabs value={tab} onValueChange={setTab}>
          <TabsList>
            <TabsTrigger value="ranking">Recommendations</TabsTrigger>
            <TabsTrigger value="scoring">Technology scoring</TabsTrigger>
            <TabsTrigger value="assumptions">Assumptions</TabsTrigger>
            <TabsTrigger value="data">Site data</TabsTrigger>
          </TabsList>
          <TabsContent value="ranking">
            <Recommendations
              ranked={ranked}
              status={search.status}
              progress={search.progress}
              total={total}
              mode={rankMode}
              onModeChange={setRankMode}
              lpspTarget={assumptions.lpspTarget}
              onLpspTargetChange={(v) => setAssumptions((a) => ({ ...a, lpspTarget: v }))}
              onRun={startSearch}
              currentId={currentId}
              onPick={(c) => {
                touched.current = true;
                setConfig(c);
                window.scrollTo({ top: 0, behavior: "smooth" });
              }}
            />
          </TabsContent>
          <TabsContent value="scoring">
            <TechScoring tech={tech} weights={weights} onWeights={setWeights} top3={ranked.slice(0, 3)} />
          </TabsContent>
          <TabsContent value="assumptions">
            <AssumptionsPanel a={assumptions} onChange={setAssumptions} onReset={() => setAssumptions(DEFAULT_ASSUMPTIONS)} />
          </TabsContent>
          <TabsContent value="data">
            <SiteDataPanel m={siteData.monthly} r={result} islandName={nearest.island.name} />
          </TabsContent>
        </Tabs>

        <footer className="flex flex-col gap-1 border-t pt-4 pb-2 text-xs text-muted-foreground">
          <p>
            All resource, cost and island figures are a synthetic dummy dataset shaped on NIOT LiDAR (Kadmat), Global Solar Atlas and NIOT OTEC profiles. Replace
            <span className="font-mono"> src/data/*.json</span> with the real datasets before using results for planning.
          </p>
          <p>Hourly profiles come from the Kadmat synthetic year, rescaled month by month to each island's capacity factors.</p>
        </footer>
      </main>
    </div>
  );
}
