import type { ReactNode } from "react";
import { Bar, BarChart, CartesianGrid, ComposedChart, Line, XAxis, YAxis, Cell } from "recharts";
import { CheckCircle2, XCircle } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ChartContainer, ChartLegend, ChartLegendContent, ChartTooltip, ChartTooltipContent, type ChartConfig } from "@/components/ui/chart";
import type { Assumptions, SimResult } from "@/lib/engine";
import { fmt, fmtCr, fmtINR, fmtLakh, fmtPct } from "@/lib/format";
import { cn } from "@/lib/utils";

const monthlyConfig: ChartConfig = {
  wind: { label: "Wind", color: "var(--s-wind)" },
  fpv: { label: "Floating solar", color: "var(--s-solar)" },
  otec: { label: "OTEC", color: "var(--s-otec)" },
  wave: { label: "Wave", color: "var(--s-wave)" },
  diesel: { label: "Diesel top-up", color: "var(--s-diesel)" },
  load: { label: "Load", color: "var(--foreground)" },
};

function Kpi({ label, value, unit, sub, tone, children }: { label: string; value: string; unit?: string; sub?: ReactNode; tone?: "magenta"; children?: ReactNode }) {
  return (
    <div className="flex min-w-0 flex-col gap-1 rounded-md bg-muted/60 p-3">
      <span className="eyebrow">{label}</span>
      <div className="flex flex-wrap items-baseline gap-x-1.5">
        <span className={cn("font-display text-2xl font-bold tnum [font-stretch:80%]", tone === "magenta" && "text-magenta")}>{value}</span>
        {unit && <span className="text-xs text-muted-foreground">{unit}</span>}
      </div>
      {sub && <div className="text-xs text-muted-foreground">{sub}</div>}
      {children}
    </div>
  );
}

export function ResultsPanel({ r, a, targetKw }: { r: SimResult; a: Assumptions; targetKw: number }) {
  const meets = r.lpsp <= a.lpspTarget;
  const dieselOnly = a.dieselPrice * a.dieselSfc;
  const saving = 1 - r.systemCOE / dieselOnly;
  const capexRows = [
    { key: "wind", label: "Wind", v: r.capexINR.wind / 1e7, color: "var(--s-wind)" },
    { key: "fpv", label: "Floating solar", v: r.capexINR.fpv / 1e7, color: "var(--s-solar)" },
    { key: "otec", label: "OTEC", v: r.capexINR.otec / 1e7, color: "var(--s-otec)" },
    { key: "wave", label: "Wave", v: r.capexINR.wave / 1e7, color: "var(--s-wave)" },
    { key: "bess", label: "Battery", v: r.capexINR.bess / 1e7, color: "var(--muted-foreground)" },
  ];
  return (
    <Card className="h-full">
      <CardHeader>
        <CardTitle className="text-lg">Results for this mix</CardTitle>
        <CardDescription>
          8,760-hour dispatch against a {fmt(targetKw)} kW net AC target. Any shortfall is met by diesel and costed as fuel.
        </CardDescription>
      </CardHeader>
      <CardContent className="flex flex-col gap-5">
        <div className="grid grid-cols-2 gap-2 lg:grid-cols-4">
          <Kpi label="RE delivered" value={fmt(r.deliveredMWh, 0)} unit="MWh/yr" sub={`of ${fmt(r.loadMWh, 0)} MWh load · PLF ${fmtPct(r.plf)}`} />
          <Kpi label="Loss of supply" value={fmtPct(r.lpsp, 2)} sub={`${fmt(r.unmetHours)} h on diesel`}>
            <Badge variant={meets ? "good" : "critical"} className="mt-1">
              {meets ? <CheckCircle2 aria-hidden /> : <XCircle aria-hidden />}
              {meets ? "Meets" : "Misses"} ≤{fmtPct(a.lpspTarget, 0)} target
            </Badge>
          </Kpi>
          <Kpi label="LCOE · RE" value={fmtINR(r.lcoeRE)} unit="/kWh" tone="magenta" sub={`System incl. diesel ${fmtINR(r.systemCOE)}/kWh`} />
          <Kpi
            label="Versus diesel only"
            value={fmtPct(saving, 0)}
            unit={saving >= 0 ? "cheaper" : "dearer"}
            sub={`Diesel fuel alone is ${fmtINR(dieselOnly)}/kWh`}
          />
          <Kpi label="CAPEX" value={fmtCr(r.capexINR.total, 1)} sub={`O&M ${fmtCr(r.opexINRyr, 2)} a year`} />
          <Kpi label="CO₂ avoided" value={fmt(r.co2AvoidedT, 0)} unit="t/yr" sub={`${fmt(r.dieselAvoidedKL, 0)} kL diesel not shipped`} />
          <Kpi label="Carbon credits" value={fmtLakh(r.carbonCreditINRyr)} unit="/yr" sub={`at $${fmt(a.carbonPriceUsd)}/tCO₂`} />
          <Kpi
            label="Surplus spilled"
            value={fmt(r.curtailedMWh, 0)}
            unit="MWh/yr"
            sub={r.freshwaterM3day > 0 ? `OTEC co-product ≈ ${fmt(r.freshwaterM3day)} m³/day water` : `Battery cycled ${fmt(r.bessThroughputMWh, 0)} MWh`}
          />
        </div>

        <div className="grid gap-5 xl:grid-cols-[1.6fr_1fr]">
          <figure className="flex min-w-0 flex-col gap-2">
            <figcaption className="flex items-baseline justify-between gap-2">
              <span className="text-sm font-semibold">Monthly energy balance</span>
              <span className="text-xs text-muted-foreground">MWh per month</span>
            </figcaption>
            <ChartContainer id="monthly" config={monthlyConfig} className="aspect-auto h-72 w-full">
              <ComposedChart data={r.monthly ?? []} margin={{ top: 8, right: 8, bottom: 0, left: -8 }}>
                <CartesianGrid vertical={false} strokeDasharray="2 4" />
                <XAxis dataKey="month" tickLine={false} axisLine={false} tickMargin={6} />
                <YAxis tickLine={false} axisLine={false} width={44} tickFormatter={(v) => fmt(v)} />
                <ChartTooltip cursor={{ fill: "var(--muted)", opacity: 0.6 }} content={<ChartTooltipContent valueFormatter={(v) => `${fmt(v, 1)} MWh`} />} />
                <ChartLegend content={<ChartLegendContent />} />
                {(["wind", "fpv", "otec", "wave", "diesel"] as const).map((k) => (
                  <Bar key={k} dataKey={k} stackId="g" fill={`var(--color-${k})`} stroke="var(--card)" strokeWidth={1} isAnimationActive={false} maxBarSize={36} />
                ))}
                <Line dataKey="load" type="stepAfter" stroke="var(--color-load)" strokeWidth={2} dot={false} isAnimationActive={false} strokeDasharray="5 3" />
              </ComposedChart>
            </ChartContainer>
          </figure>
          <figure className="flex min-w-0 flex-col gap-2">
            <figcaption className="flex items-baseline justify-between gap-2">
              <span className="text-sm font-semibold">CAPEX by component</span>
              <span className="text-xs text-muted-foreground">₹ crore · total {fmt(r.capexINR.total / 1e7, 1)}</span>
            </figcaption>
            <ChartContainer id="capex" config={{ v: { label: "CAPEX", color: "var(--primary)" } }} className="aspect-auto h-72 w-full">
              <BarChart data={capexRows} layout="vertical" margin={{ top: 8, right: 40, bottom: 0, left: 8 }}>
                <CartesianGrid horizontal={false} strokeDasharray="2 4" />
                <XAxis type="number" tickLine={false} axisLine={false} tickFormatter={(v) => fmt(v)} />
                <YAxis type="category" dataKey="label" tickLine={false} axisLine={false} width={92} />
                <ChartTooltip cursor={{ fill: "var(--muted)", opacity: 0.6 }} content={<ChartTooltipContent hideLabel valueFormatter={(v) => `₹${fmt(v, 2)} Cr`} />} />
                <Bar dataKey="v" radius={[0, 4, 4, 0]} isAnimationActive={false} maxBarSize={22} label={{ position: "right", fill: "var(--foreground)", fontSize: 11, formatter: (v: number) => (v > 0 ? fmt(v, 1) : "") }}>
                  {capexRows.map((c) => (
                    <Cell key={c.key} fill={c.color} />
                  ))}
                </Bar>
              </BarChart>
            </ChartContainer>
          </figure>
        </div>
      </CardContent>
    </Card>
  );
}
