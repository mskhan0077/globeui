import { useEffect, useMemo, useRef, useState } from "react";
import { Check, Copy, Download, FileSpreadsheet, FileText } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { buildCSV, buildPDF, downloadBlob, type ExportInput } from "@/lib/export";

// When the app runs inside the claude.ai artifact viewer, plain downloads are blocked and files go through
// the viewer's `downloads` capability instead. Locally (npm run dev / build) normal browser downloads are used.
type HostDownloads = { save: (r: { filename: string; data: string | Blob }) => Promise<{ status: string }> };
const embedded = (() => {
  try {
    return window.self !== window.top;
  } catch {
    return true;
  }
})();
async function hostDownloads(): Promise<HostDownloads | null> {
  const c = (window as unknown as { claude?: { use?: (n: string) => Promise<unknown> } }).claude;
  if (!c?.use) return null;
  try {
    return ((await c.use("downloads")) as HostDownloads | null) ?? null;
  } catch {
    return null;
  }
}

export function ExportDialog({ input }: { input: ExportInput }) {
  const [open, setOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const [busy, setBusy] = useState<null | "csv" | "pdf">(null);
  const [note, setNote] = useState<string | null>(null);
  const [host, setHost] = useState<HostDownloads | null | undefined>(embedded ? undefined : null);
  const areaRef = useRef<HTMLTextAreaElement | null>(null);
  const csv = useMemo(() => (open ? buildCSV(input) : ""), [open, input]);
  const slug = input.siteName.replace(/[^a-z0-9]+/gi, "_").replace(/^_|_$/g, "") || "site";

  useEffect(() => {
    if (open && embedded && host === undefined) hostDownloads().then(setHost);
  }, [open, host]);

  const canDownload = !embedded || !!host;

  const save = async (kind: "csv" | "pdf") => {
    setBusy(kind);
    setNote(null);
    try {
      const blob = kind === "csv" ? new Blob([csv], { type: "text/csv;charset=utf-8" }) : await buildPDF(input);
      const filename = `BlueGrid_${slug}.${kind}`;
      if (!embedded) downloadBlob(blob, filename);
      else if (host) {
        await host.save({ filename, data: blob });
        setNote(`${filename} saved.`);
      }
    } catch (e) {
      const code = (e as { code?: string })?.code;
      if (code !== "declined") setNote(code === "rate_limited" ? "A save prompt is already open." : "The file could not be saved here. Copy the CSV instead.");
    } finally {
      setBusy(null);
    }
  };

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(csv);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      areaRef.current?.focus();
      areaRef.current?.select();
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm">
          <Download aria-hidden /> Export
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-xl">
        <DialogHeader>
          <DialogTitle>Export summary for planners</DialogTitle>
          <DialogDescription>Site, mix, KPIs, monthly balance, technology scores, top ranked mixes and every assumption.</DialogDescription>
        </DialogHeader>
        {canDownload ? (
          <div className="grid gap-2 sm:grid-cols-2">
            <Button onClick={() => save("csv")} disabled={busy !== null}>
              <FileSpreadsheet aria-hidden /> {busy === "csv" ? "Preparing…" : "Download CSV"}
            </Button>
            <Button variant="accent" onClick={() => save("pdf")} disabled={busy !== null}>
              <FileText aria-hidden /> {busy === "pdf" ? "Building PDF…" : "Download PDF"}
            </Button>
          </div>
        ) : host === undefined ? (
          <p className="text-[13px] text-muted-foreground">Checking whether downloads are allowed here…</p>
        ) : (
          <p className="rounded-md bg-warn-soft p-2.5 text-[13px] text-warn">
            Downloads aren't available in this view. Copy the CSV below, or run the app locally (npm run dev) for CSV and PDF files.
          </p>
        )}
        {note && <p className="text-[13px] text-muted-foreground">{note}</p>}
        <div className="grid gap-2">
          <div className="flex items-center justify-between">
            <span className="eyebrow">CSV preview</span>
            <Button variant="ghost" size="sm" onClick={copy}>
              {copied ? <Check aria-hidden /> : <Copy aria-hidden />} {copied ? "Copied" : "Copy CSV"}
            </Button>
          </div>
          <textarea
            id="csv-preview"
            ref={areaRef}
            readOnly
            value={csv}
            className="h-56 w-full resize-y rounded-md border bg-muted/50 p-2 font-mono text-[11px] leading-snug"
          />
        </div>
      </DialogContent>
    </Dialog>
  );
}
