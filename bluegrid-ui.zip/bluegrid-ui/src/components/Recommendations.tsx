import { Bar, BarChart, CartesianGrid, Cell, XAxis, YAxis } from "recharts";
import { Loader2, Play } from "lucide-react";
import { Card, CardAction, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart";
import type { Candidate, Config, RankMode } from "@/lib/engine";
import { fmt, fmtKw, fmtKwh, fmtPct } from "@/lib/format";

function Mix({ c }: { c: Config }) {
  const parts: [string, number, string, string][] = [
    ["W", c.wind, "var(--s-wind)", "kW"],
    ["PV", c.fpv, "var(--s-solar)", "kW"],
    ["OT", c.otec, "var(--s-otec)", "kW"],
    ["WV", c.wave, "var(--s-wave)", "kW"],
  ];
  return (
    <div className="flex flex-wrap items-center gap-1">
      {parts
        .filter(([, v]) => v > 0)
        .map(([k, v, col]) => (
          <span key={k} className="inline-flex items-center gap-1 rounded border px-1.5 py-0.5 font-mono text-[11px]">
            <span className="size-2 rounded-[2px]" style={{ background: col }} aria-hidden />
            {k} {fmtKw(v)}
          </span>
        ))}
      {c.bess > 0 && <span className="inline-flex items-center gap-1 rounded border border-dashed px-1.5 py-0.5 font-mono text-[11px]">BESS {fmtKwh(c.bess)}</span>}
    </div>
  );
}

export function Recommendations({
  ranked,
  status,
  progress,
  total,
  mode,
  onModeChange,
  lpspTarget,
  onLpspTargetChange,
  onRun,
  currentId,
  onPick,
}: {
  ranked: Candidate[];
  status: "idle" | "running" | "done";
  progress: number;
  total: number;
  mode: RankMode;
  onModeChange: (m: RankMode) => void;
  lpspTarget: number;
  onLpspTargetChange: (v: number) => void;
  onRun: () => void;
  currentId: string;
  onPick: (c: Config) => void;
}) {
  const top = ranked.slice(0, 15);
  const feasibleCount = ranked.filter((c) => c.feasible).length;
  const chartData = top.slice(0, 10).map((c) => ({ name: `#${c.rank}`, v: mode === "cost" ? c.lcoeRE : c.scores.weighted, id: c.id }));
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">Ranked recommendations</CardTitle>
        <CardDescription>
          {status === "running"
            ? `Simulating ${fmt(progress)} of ${fmt(total)} mixes…`
            : ranked.length
              ? `${fmt(ranked.length)} mixes simulated hour by hour · ${fmt(feasibleCount)} meet the reliability target. Click a row to load it.`
              : "Run the search to rank every mix in the grid."}
        </CardDescription>
        <CardAction>
          <Button variant="outline" size="sm" onClick={onRun} disabled={status === "running"}>
            {status === "running" ? <Loader2 className="animate-spin" aria-hidden /> : <Play aria-hidden />}
            {status === "running" ? "Searching" : "Re-run search"}
          </Button>
        </CardAction>
      </CardHeader>
      <CardContent className="flex flex-col gap-4">
        <div className="flex flex-wrap items-end gap-4">
          <div className="grid gap-1.5">
            <Label htmlFor="rank-mode">Rank by</Label>
            <Select value={mode} onValueChange={(v) => onModeChange(v as RankMode)}>
              <SelectTrigger id="rank-mode" className="w-60">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="cost">Lowest LCOE meeting target</SelectItem>
                <SelectItem value="score">Weighted matrix score</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="lpsp-target">Max loss of supply (%)</Label>
            <Input
              id="lpsp-target"
              type="number"
              min={0}
              max={50}
              step={0.5}
              className="w-28 font-mono tnum"
              value={Number((lpspTarget * 100).toFixed(2))}
              onChange={(e) => {
                const v = Number(e.target.value);
                if (Number.isFinite(v) && v >= 0 && v <= 50) onLpspTargetChange(v / 100);
              }}
            />
          </div>
          {status === "running" && (
            <div className="h-1.5 min-w-40 flex-1 overflow-hidden rounded-full bg-muted" role="progressbar" aria-valuenow={progress} aria-valuemax={total}>
              <div className="h-full bg-magenta transition-[width]" style={{ width: `${(100 * progress) / Math.max(total, 1)}%` }} />
            </div>
          )}
        </div>

        {top.length > 0 && (
          <div className="grid gap-5 xl:grid-cols-[1fr_2.2fr]">
            <figure className="flex min-w-0 flex-col gap-2">
              <figcaption className="flex items-baseline justify-between">
                <span className="text-sm font-semibold">{mode === "cost" ? "LCOE of the top 10" : "Weighted score of the top 10"}</span>
                <span className="text-xs text-muted-foreground">{mode === "cost" ? "₹/kWh" : "0–10"}</span>
              </figcaption>
              <ChartContainer id="rank" config={{ v: { label: mode === "cost" ? "LCOE" : "Score", color: "var(--primary)" } }} className="aspect-auto h-80 w-full">
                <BarChart data={chartData} layout="vertical" margin={{ top: 4, right: 44, bottom: 0, left: 0 }}>
                  <CartesianGrid horizontal={false} strokeDasharray="2 4" />
                  <XAxis type="number" tickLine={false} axisLine={false} tickFormatter={(v) => fmt(v, 0)} />
                  <YAxis type="category" dataKey="name" tickLine={false} axisLine={false} width={34} />
                  <ChartTooltip cursor={{ fill: "var(--muted)", opacity: 0.6 }} content={<ChartTooltipContent valueFormatter={(v) => (mode === "cost" ? `₹${fmt(v, 2)}/kWh` : fmt(v, 2))} />} />
                  <Bar dataKey="v" radius={[0, 4, 4, 0]} maxBarSize={18} isAnimationActive={false} label={{ position: "right", fill: "var(--foreground)", fontSize: 11, formatter: (v: number) => fmt(v, 2) }}>
                    {chartData.map((d) => (
                      <Cell key={d.id} fill={d.id === currentId ? "var(--magenta)" : "var(--primary)"} />
                    ))}
                  </Bar>
                </BarChart>
              </ChartContainer>
              <p className="text-xs text-muted-foreground">Magenta bar = the mix loaded in the sliders.</p>
            </figure>
            <div className="min-w-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>#</TableHead>
                    <TableHead>Mix</TableHead>
                    <TableHead className="text-right">LCOE ₹/kWh</TableHead>
                    <TableHead className="text-right">CAPEX ₹ Cr</TableHead>
                    <TableHead className="text-right">LPSP</TableHead>
                    <TableHead className="text-right">CO₂ t/yr</TableHead>
                    <TableHead className="text-right">Score</TableHead>
                    <TableHead>Target</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {top.map((c) => (
                    <TableRow
                      key={c.id}
                      data-state={c.id === currentId ? "selected" : undefined}
                      className="cursor-pointer"
                      tabIndex={0}
                      onClick={() => onPick(c.config)}
                      onKeyDown={(e) => (e.key === "Enter" || e.key === " ") && onPick(c.config)}
                    >
                      <TableCell className="font-mono">{c.rank}</TableCell>
                      <TableCell className="min-w-[230px] whitespace-normal">
                        <Mix c={c.config} />
                      </TableCell>
                      <TableCell className="text-right font-mono">{fmt(c.lcoeRE, 2)}</TableCell>
                      <TableCell className="text-right font-mono">{fmt(c.capexINR.total / 1e7, 1)}</TableCell>
                      <TableCell className="text-right font-mono">{fmtPct(c.lpsp, 1)}</TableCell>
                      <TableCell className="text-right font-mono">{fmt(c.co2AvoidedT, 0)}</TableCell>
                      <TableCell className="text-right font-mono">{fmt(c.scores.weighted, 2)}</TableCell>
                      <TableCell>{c.feasible ? <Badge variant="good">Meets</Badge> : <Badge variant="critical">Misses</Badge>}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
