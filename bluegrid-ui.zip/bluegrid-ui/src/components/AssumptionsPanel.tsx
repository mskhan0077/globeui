import { RotateCcw } from "lucide-react";
import { Card, CardAction, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { crf, dieselEF, type Assumptions, GEN_KEYS, TECH_LABEL, TECH_PARAMS } from "@/lib/engine";
import { fmt } from "@/lib/format";

type NumKey = { [K in keyof Assumptions]: Assumptions[K] extends number ? K : never }[keyof Assumptions];

function NumField({ id, label, value, onChange, step = 1, scale = 1, suffix }: { id: string; label: string; value: number; onChange: (v: number) => void; step?: number; scale?: number; suffix?: string }) {
  return (
    <div className="grid gap-1.5">
      <Label htmlFor={id}>{label}</Label>
      <div className="flex items-center gap-1.5">
        <Input
          id={id}
          type="number"
          step={step}
          className="font-mono tnum"
          value={Number((value * scale).toFixed(4))}
          onChange={(e) => {
            const v = Number(e.target.value);
            if (Number.isFinite(v) && v >= 0) onChange(v / scale);
          }}
        />
        {suffix && <span className="w-14 shrink-0 text-xs text-muted-foreground">{suffix}</span>}
      </div>
    </div>
  );
}

export function AssumptionsPanel({ a, onChange, onReset }: { a: Assumptions; onChange: (a: Assumptions) => void; onReset: () => void }) {
  const set = (k: NumKey) => (v: number) => onChange({ ...a, [k]: v });
  return (
    <div className="grid gap-4 xl:grid-cols-2">
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Finance, diesel and carbon</CardTitle>
          <CardDescription>
            Capital recovery factor {fmt(crf(a.discountRate, a.lifeYr), 4)} · diesel emits {fmt(dieselEF(a), 3)} tCO₂/MWh · fuel alone costs ₹{fmt(a.dieselPrice * a.dieselSfc, 2)}/kWh
          </CardDescription>
          <CardAction>
            <Button variant="outline" size="sm" onClick={onReset}>
              <RotateCcw aria-hidden /> Defaults
            </Button>
          </CardAction>
        </CardHeader>
        <CardContent className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <NumField id="a-dr" label="Discount rate (real)" value={a.discountRate} scale={100} step={0.5} suffix="%" onChange={set("discountRate")} />
          <NumField id="a-life" label="Project life" value={a.lifeYr} suffix="years" onChange={set("lifeYr")} />
          <NumField id="a-fx" label="Exchange rate" value={a.fx} step={0.5} suffix="₹/USD" onChange={set("fx")} />
          <NumField id="a-carbon" label="Carbon price" value={a.carbonPriceUsd} suffix="USD/t" onChange={set("carbonPriceUsd")} />
          <NumField id="a-dp" label="Landed diesel price" value={a.dieselPrice} suffix="₹/L" onChange={set("dieselPrice")} />
          <NumField id="a-sfc" label="Diesel fuel use" value={a.dieselSfc} step={0.01} suffix="L/kWh" onChange={set("dieselSfc")} />
          <NumField id="a-rte" label="Battery round-trip efficiency" value={a.bessRte} scale={100} suffix="%" onChange={set("bessRte")} />
          <NumField id="a-dod" label="Battery depth of discharge" value={a.bessDod} scale={100} suffix="%" onChange={set("bessDod")} />
          <NumField id="a-crate" label="Battery C-rate" value={a.bessCRate} step={0.05} suffix="1/h" onChange={set("bessCRate")} />
          <NumField id="a-repl" label="Battery replacement year" value={a.bessReplYear} suffix="year" onChange={set("bessReplYear")} />
          <div className="flex items-center justify-between gap-3 rounded-md border p-3 sm:col-span-2">
            <div className="grid gap-0.5">
              <Label htmlFor="a-sub">Apply central subsidies</Label>
              <span className="text-xs text-muted-foreground">
                Floating-PV CFA ₹{fmt(a.fpvCfaPerKw)}/kW (PM Surya Sarovar) and BESS VGF ₹{fmt(a.bessVgfPerKwh)}/kWh
              </span>
            </div>
            <Switch id="a-sub" checked={a.applySubsidies} onCheckedChange={(v) => onChange({ ...a, applySubsidies: v })} />
          </div>
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Island-delivered costs</CardTitle>
          <CardDescription>Mainland benchmark × island logistics factor. Edit to test vendor quotes.</CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col gap-4">
          {[...GEN_KEYS, "bess" as const].map((k) => (
            <div key={k} className="grid gap-3 sm:grid-cols-2">
              <NumField
                id={`capex-${k}`}
                label={`${TECH_LABEL[k]} CAPEX`}
                value={a.capex[k]}
                step={1000}
                suffix={k === "bess" ? "₹/kWh" : "₹/kW"}
                onChange={(v) => onChange({ ...a, capex: { ...a.capex, [k]: v } })}
              />
              <NumField
                id={`opex-${k}`}
                label="O&M per year"
                value={a.opex[k]}
                step={100}
                suffix={k === "bess" ? "₹/kWh" : "₹/kW"}
                onChange={(v) => onChange({ ...a, opex: { ...a.opex, [k]: v } })}
              />
              <p className="text-xs text-muted-foreground sm:col-span-2">{TECH_PARAMS[k].capexSource}</p>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}
