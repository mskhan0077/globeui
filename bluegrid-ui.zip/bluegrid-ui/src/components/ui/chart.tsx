// shadcn/ui chart primitives (Recharts wrapper) – trimmed to what BlueGrid uses.
import * as React from "react";
import * as RechartsPrimitive from "recharts";
import { cn } from "@/lib/utils";

export type ChartConfig = {
  [k: string]: { label?: React.ReactNode; color?: string; icon?: React.ComponentType };
};

const ChartContext = React.createContext<{ config: ChartConfig } | null>(null);
function useChart() {
  const ctx = React.useContext(ChartContext);
  if (!ctx) throw new Error("useChart must be used within a <ChartContainer />");
  return ctx;
}

function ChartContainer({
  id,
  className,
  children,
  config,
  ...props
}: React.ComponentProps<"div"> & {
  config: ChartConfig;
  children: React.ComponentProps<typeof RechartsPrimitive.ResponsiveContainer>["children"];
}) {
  const uid = React.useId();
  const chartId = `chart-${id || uid.replace(/:/g, "")}`;
  const vars = Object.fromEntries(
    Object.entries(config).filter(([, c]) => c.color).map(([k, c]) => [`--color-${k}`, c.color])
  ) as React.CSSProperties;
  return (
    <ChartContext.Provider value={{ config }}>
      <div
        data-slot="chart"
        data-chart={chartId}
        style={vars}
        className={cn(
          "flex aspect-video justify-center text-xs [&_.recharts-cartesian-axis-tick_text]:fill-muted-foreground [&_.recharts-cartesian-grid_line[stroke='#ccc']]:stroke-[var(--grid)] [&_.recharts-curve.recharts-tooltip-cursor]:stroke-border [&_.recharts-polar-grid_[stroke='#ccc']]:stroke-[var(--grid)] [&_.recharts-radial-bar-background-sector]:fill-muted [&_.recharts-rectangle.recharts-tooltip-cursor]:fill-muted/60 [&_.recharts-reference-line_[stroke='#ccc']]:stroke-border [&_.recharts-sector]:outline-hidden [&_.recharts-surface]:outline-hidden [&_.recharts-polar-angle-axis-tick_text]:fill-foreground [&_.recharts-polar-radius-axis-tick_text]:fill-muted-foreground",
          className
        )}
        {...props}
      >
        <RechartsPrimitive.ResponsiveContainer>{children}</RechartsPrimitive.ResponsiveContainer>
      </div>
    </ChartContext.Provider>
  );
}

const ChartTooltip = RechartsPrimitive.Tooltip;

type TooltipItem = { dataKey?: string | number; name?: string | number; value?: number | string; color?: string; payload?: Record<string, unknown> };

function ChartTooltipContent({
  active,
  payload,
  label,
  valueFormatter,
  labelFormatter,
  hideLabel = false,
}: {
  active?: boolean;
  payload?: TooltipItem[];
  label?: React.ReactNode;
  valueFormatter?: (v: number, key: string) => string;
  labelFormatter?: (label: React.ReactNode) => React.ReactNode;
  hideLabel?: boolean;
}) {
  const { config } = useChart();
  if (!active || !payload?.length) return null;
  return (
    <div className="grid min-w-[9rem] gap-1.5 rounded-md border bg-popover px-2.5 py-1.5 text-xs text-popover-foreground shadow-lg">
      {!hideLabel && <div className="font-medium">{labelFormatter ? labelFormatter(label) : label}</div>}
      <div className="grid gap-1">
        {payload.map((item) => {
          const key = String(item.dataKey ?? item.name ?? "value");
          const cfg = config[key];
          const color = cfg?.color ?? item.color;
          const v = typeof item.value === "number" ? item.value : Number(item.value);
          return (
            <div key={key} className="flex items-center gap-2">
              <span className="size-2.5 shrink-0 rounded-[2px]" style={{ background: color }} />
              <span className="text-muted-foreground">{cfg?.label ?? item.name}</span>
              <span className="ml-auto font-mono font-medium tnum text-foreground">
                {valueFormatter ? valueFormatter(v, key) : v.toLocaleString()}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

const ChartLegend = RechartsPrimitive.Legend;

function ChartLegendContent({ payload, className }: { payload?: { dataKey?: string | number; value?: string; color?: string }[]; className?: string }) {
  const { config } = useChart();
  if (!payload?.length) return null;
  return (
    <div className={cn("flex flex-wrap items-center justify-center gap-x-4 gap-y-1 pt-2", className)}>
      {payload.map((item) => {
        const key = String(item.dataKey ?? item.value);
        const cfg = config[key];
        return (
          <div key={key} className="flex items-center gap-1.5 text-muted-foreground">
            <span className="size-2.5 shrink-0 rounded-[2px]" style={{ background: cfg?.color ?? item.color }} />
            {cfg?.label ?? item.value}
          </div>
        );
      })}
    </div>
  );
}

export { ChartContainer, ChartTooltip, ChartTooltipContent, ChartLegend, ChartLegendContent };
