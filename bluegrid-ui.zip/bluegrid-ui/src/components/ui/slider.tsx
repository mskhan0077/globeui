import * as React from "react";
import * as SliderPrimitive from "@radix-ui/react-slider";
import { cn } from "@/lib/utils";

function Slider({
  className,
  rangeColor,
  ...props
}: React.ComponentProps<typeof SliderPrimitive.Root> & { rangeColor?: string }) {
  return (
    <SliderPrimitive.Root
      data-slot="slider"
      className={cn("relative flex w-full touch-none items-center select-none data-[disabled]:opacity-50 py-2", className)}
      {...props}
    >
      <SliderPrimitive.Track data-slot="slider-track" className="relative h-1.5 w-full grow overflow-hidden rounded-full bg-muted">
        <SliderPrimitive.Range data-slot="slider-range" className="absolute h-full" style={{ background: rangeColor ?? "var(--primary)" }} />
      </SliderPrimitive.Track>
      <SliderPrimitive.Thumb
        data-slot="slider-thumb"
        className="block size-4 shrink-0 rounded-full border-2 bg-card shadow-sm transition-[box-shadow] hover:ring-4 hover:ring-ring/20 focus-visible:ring-4 focus-visible:ring-ring/40 focus-visible:outline-none"
        style={{ borderColor: rangeColor ?? "var(--primary)" }}
      />
    </SliderPrimitive.Root>
  );
}

export { Slider };
