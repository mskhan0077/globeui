import { RotateCcw, Sparkles } from "lucide-react";
import { Card, CardAction, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import type { Assumptions, Candidate, Config, TechScore } from "@/lib/engine";
import { fmt, fmtPct } from "@/lib/format";

type Key = keyof Config;
const ROWS: { key: Key; label: string; unit: string; max: number; step: number; color: string }[] = [
  { key: "wind", label: "Wind turbines", unit: "kW", max: 6000, step: 100, color: "var(--s-wind)" },
  { key: "fpv", label: "Floating solar PV", unit: "kWp", max: 12000, step: 100, color: "var(--s-solar)" },
  { key: "otec", label: "OTEC (net)", unit: "kW", max: 2000, step: 50, color: "var(--s-otec)" },
  { key: "wave", label: "Wave energy", unit: "kW", max: 2000, step: 50, color: "var(--s-wave)" },
  { key: "bess", label: "Battery storage", unit: "kWh", max: 40000, step: 500, color: "var(--muted-foreground)" },
];

export function ConfigPanel({
  config,
  onChange,
  assumptions,
  tech,
  best,
  matchRank,
  onApplyBest,
  onReset,
}: {
  config: Config;
  onChange: (c: Config) => void;
  assumptions: Assumptions;
  tech: TechScore[];
  best: Candidate | null;
  matchRank: number | null;
  onApplyBest: () => void;
  onReset: () => void;
}) {
  const cf = Object.fromEntries(tech.map((t) => [t.key, t.annualCF])) as Record<string, number>;
  return (
    <Card className="h-full">
      <CardHeader>
        <CardTitle className="text-lg">Configuration</CardTitle>
        <CardDescription>Drag to size each source. Results update instantly with an hourly battery simulation.</CardDescription>
        <CardAction>
          {matchRank ? <Badge variant="magenta">Recommendation #{matchRank}</Badge> : <Badge variant="outline">Custom mix</Badge>}
        </CardAction>
      </CardHeader>
      <CardContent className="flex flex-col gap-5">
        {ROWS.map((r) => {
          const v = config[r.key];
          const capex = assumptions.capex[r.key];
          return (
            <div key={r.key} className="grid gap-1">
              <div className="flex items-center justify-between gap-3">
                <label htmlFor={`cfg-${r.key}`} className="flex items-center gap-2 text-[13px] font-medium">
                  <span className="size-2.5 rounded-[2px]" style={{ background: r.color }} aria-hidden />
                  {r.label}
                </label>
                <div className="flex items-center gap-1.5">
                  <Input
                    id={`cfg-${r.key}`}
                    type="number"
                    min={0}
                    max={r.max}
                    step={r.step}
                    value={v}
                    onChange={(e) => {
                      const n = Math.max(0, Math.min(r.max, Number(e.target.value) || 0));
                      onChange({ ...config, [r.key]: n });
                    }}
                    className="h-8 w-24 text-right font-mono tnum"
                  />
                  <span className="w-8 text-xs text-muted-foreground">{r.unit}</span>
                </div>
              </div>
              <Slider
                aria-label={r.label}
                value={[v]}
                min={0}
                max={r.max}
                step={r.step}
                rangeColor={r.color}
                onValueChange={([n]) => onChange({ ...config, [r.key]: n })}
              />
              <p className="font-mono text-[11px] text-muted-foreground tnum">
                ₹{fmt(capex / 1000, capex >= 100000 ? 0 : 1)}k per {r.unit === "kWh" ? "kWh" : "kW"}
                {r.key !== "bess" && cf[r.key] !== undefined && <> · annual CF {fmtPct(cf[r.key])}</>}
                {r.key === "bess" && <> · {fmt(v * assumptions.bessCRate)} kW max power · RTE {fmtPct(assumptions.bessRte, 0)}</>}
              </p>
            </div>
          );
        })}
        <div className="flex flex-wrap gap-2 pt-1">
          <Button variant="accent" onClick={onApplyBest} disabled={!best}>
            <Sparkles aria-hidden /> Use lowest-cost mix
          </Button>
          <Button variant="outline" onClick={onReset}>
            <RotateCcw aria-hidden /> Reset
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
