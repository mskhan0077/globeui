import { Area, AreaChart, XAxis, YAxis } from "recharts";
import { ChartContainer, ChartTooltip, ChartTooltipContent, type ChartConfig } from "@/components/ui/chart";
import { MONTHS, type MonthlySeries } from "@/lib/engine";
import { fmt } from "@/lib/format";

const MONSOON = [5, 6, 7, 8];
const mean = (a: number[]) => a.reduce((s, v) => s + v, 0) / a.length;
const meanIdx = (a: number[], idx: number[]) => mean(idx.map((i) => a[i]));
const notIdx = (idx: number[]) => Array.from({ length: 12 }, (_, i) => i).filter((i) => !idx.includes(i));

function Tile({
  id,
  title,
  value,
  unit,
  detail,
  series,
  color,
  unitShort,
  decimals,
}: {
  id: string;
  title: string;
  value: string;
  unit: string;
  detail: string;
  series: number[];
  color: string;
  unitShort: string;
  decimals: number;
}) {
  const data = series.map((v, i) => ({ month: MONTHS[i], v }));
  const config: ChartConfig = { v: { label: title, color } };
  return (
    <div className="flex min-w-0 flex-col gap-2 rounded-lg border bg-card p-4">
      <div className="flex items-center gap-2">
        <span className="size-2.5 rounded-[2px]" style={{ background: color }} aria-hidden />
        <span className="eyebrow">{title}</span>
      </div>
      <div className="flex items-baseline gap-1.5">
        <span className="font-display text-3xl font-bold tnum [font-stretch:80%]">{value}</span>
        <span className="text-muted-foreground text-[13px]">{unit}</span>
      </div>
      <p className="text-muted-foreground text-xs">{detail}</p>
      <ChartContainer id={id} config={config} className="aspect-auto h-14 w-full">
        <AreaChart data={data} margin={{ top: 4, right: 2, bottom: 0, left: 2 }}>
          <defs>
            <linearGradient id={`fill-${id}`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={color} stopOpacity={0.35} />
              <stop offset="100%" stopColor={color} stopOpacity={0.02} />
            </linearGradient>
          </defs>
          <XAxis dataKey="month" hide />
          <YAxis hide domain={["dataMin", "dataMax"]} />
          <ChartTooltip
            cursor={{ stroke: "var(--border)" }}
            content={<ChartTooltipContent valueFormatter={(v) => `${fmt(v, decimals)} ${unitShort}`} />}
          />
          <Area dataKey="v" type="monotone" stroke={color} strokeWidth={2} fill={`url(#fill-${id})`} isAnimationActive={false} activeDot={{ r: 4, strokeWidth: 2, stroke: "var(--card)" }} />
        </AreaChart>
      </ChartContainer>
      <div className="flex justify-between font-mono text-[10px] text-muted-foreground">
        <span>Jan</span>
        <span>Jun–Sep monsoon</span>
        <span>Dec</span>
      </div>
    </div>
  );
}

export function ResourceStrip({ m, islandName }: { m: MonthlySeries; islandName: string }) {
  const non = notIdx(MONSOON);
  const pvYear = m.pvoutMonth.reduce((s, v) => s + v, 0);
  return (
    <section aria-labelledby="resource-heading" className="flex flex-col gap-3">
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <h2 id="resource-heading" className="text-xl font-bold">
          Resource at {islandName}
        </h2>
        <p className="text-muted-foreground text-[13px]">Monthly means from the pre-loaded dataset · hover a curve for the month</p>
      </div>
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <Tile
          id="wind"
          title="Wind · 80 m hub"
          value={fmt(mean(m.ws80), 1)}
          unit="m/s mean"
          detail={`${fmt(meanIdx(m.ws80, MONSOON), 1)} m/s in the SW monsoon, ${fmt(meanIdx(m.ws80, non), 1)} m/s the rest of the year`}
          series={m.ws80}
          color="var(--s-wind)"
          unitShort="m/s"
          decimals={1}
        />
        <Tile
          id="solar"
          title="Solar · GHI"
          value={fmt(mean(m.ghi), 2)}
          unit="kWh/m²/day"
          detail={`Floating PV yield ${fmt(pvYear, 0)} kWh/kWp a year, lowest in Jun–Jul`}
          series={m.ghi}
          color="var(--s-solar)"
          unitShort="kWh/m²/d"
          decimals={2}
        />
        <Tile
          id="otec"
          title="OTEC · ΔT surface–1,000 m"
          value={fmt(mean(m.dT), 1)}
          unit="°C mean"
          detail={`Range ${fmt(Math.min(...m.dT), 1)}–${fmt(Math.max(...m.dT), 1)} °C; 20 °C is the usual viability floor`}
          series={m.dT}
          color="var(--s-otec)"
          unitShort="°C"
          decimals={1}
        />
        <Tile
          id="wave"
          title="Wave power"
          value={fmt(mean(m.waveP), 1)}
          unit="kW/m mean"
          detail={`Peaks at ${fmt(Math.max(...m.waveP), 0)} kW/m in the monsoon, ${fmt(Math.min(...m.waveP), 1)} kW/m at the low`}
          series={m.waveP}
          color="var(--s-wave)"
          unitShort="kW/m"
          decimals={1}
        />
      </div>
    </section>
  );
}
