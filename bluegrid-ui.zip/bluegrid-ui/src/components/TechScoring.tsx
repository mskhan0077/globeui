import { PolarAngleAxis, PolarGrid, PolarRadiusAxis, Radar, RadarChart } from "recharts";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ChartContainer, ChartLegend, ChartLegendContent, ChartTooltip, ChartTooltipContent, type ChartConfig } from "@/components/ui/chart";
import { CRITERIA, type Candidate, type TechScore, type Weights } from "@/lib/engine";
import { fmt, fmtPct } from "@/lib/format";

const techConfig: ChartConfig = {
  wind: { label: "Wind", color: "var(--s-wind)" },
  fpv: { label: "Floating solar", color: "var(--s-solar)" },
  otec: { label: "OTEC", color: "var(--s-otec)" },
  wave: { label: "Wave", color: "var(--s-wave)" },
};
const mixConfig: ChartConfig = {
  m1: { label: "#1", color: "var(--magenta)" },
  m2: { label: "#2", color: "var(--s-wind)" },
  m3: { label: "#3", color: "var(--s-otec)" },
};

export function TechScoring({ tech, weights, onWeights, top3 }: { tech: TechScore[]; weights: Weights; onWeights: (w: Weights) => void; top3: Candidate[] }) {
  const wsum = weights.resource + weights.capex + weights.reliability + weights.sustainability || 1;
  const radar = CRITERIA.map((c) => ({
    criterion: c.label,
    ...Object.fromEntries(tech.map((t) => [t.key, Number(t[c.key].toFixed(2))])),
  }));
  const mixRadar = CRITERIA.map((c) => ({
    criterion: c.label,
    ...Object.fromEntries(top3.map((m, i) => [`m${i + 1}`, Number(m.scores[c.key].toFixed(2))])),
  }));
  const ranked = [...tech].sort((a, b) => b.weighted - a.weighted);
  return (
    <div className="grid gap-4 xl:grid-cols-[1fr_1fr]">
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Technology scoring</CardTitle>
          <CardDescription>Each source scored 0–10 at this site. Weights apply to both the technologies and the ranked mixes.</CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col gap-5">
          <ChartContainer id="tech-radar" config={techConfig} className="aspect-auto h-80 w-full">
            <RadarChart data={radar} outerRadius="72%">
              <PolarGrid />
              <PolarAngleAxis dataKey="criterion" tick={{ fontSize: 12 }} />
              <PolarRadiusAxis domain={[0, 10]} tickCount={6} axisLine={false} tick={{ fontSize: 10 }} angle={90} />
              <ChartTooltip content={<ChartTooltipContent valueFormatter={(v) => fmt(v, 1)} />} />
              <ChartLegend content={<ChartLegendContent />} />
              {tech.map((t) => (
                <Radar key={t.key} dataKey={t.key} stroke={`var(--color-${t.key})`} fill={`var(--color-${t.key})`} fillOpacity={0.08} strokeWidth={2} isAnimationActive={false} dot={{ r: 3 }} />
              ))}
            </RadarChart>
          </ChartContainer>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Rank</TableHead>
                <TableHead>Technology</TableHead>
                <TableHead className="text-right">Annual CF</TableHead>
                <TableHead className="text-right">Worst month</TableHead>
                {CRITERIA.map((c) => (
                  <TableHead key={c.key} className="text-right">
                    {c.label.split(" ")[0]}
                  </TableHead>
                ))}
                <TableHead className="text-right">Weighted</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {ranked.map((t, i) => (
                <TableRow key={t.key}>
                  <TableCell className="font-mono">{i + 1}</TableCell>
                  <TableCell>
                    <span className="inline-flex items-center gap-2">
                      <span className="size-2.5 rounded-[2px]" style={{ background: techConfig[t.key].color }} aria-hidden />
                      {t.label}
                    </span>
                  </TableCell>
                  <TableCell className="text-right font-mono">{fmtPct(t.annualCF)}</TableCell>
                  <TableCell className="text-right font-mono">{fmtPct(t.minMonthCF)}</TableCell>
                  {CRITERIA.map((c) => (
                    <TableCell key={c.key} className="text-right font-mono">
                      {fmt(t[c.key], 1)}
                    </TableCell>
                  ))}
                  <TableCell className="text-right font-mono font-semibold">{fmt(t.weighted, 2)}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <div className="flex flex-col gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Criteria weights</CardTitle>
            <CardDescription>Normalised to 100% · currently {CRITERIA.map((c) => `${c.label.split(" ")[0]} ${fmtPct(weights[c.key] / wsum, 0)}`).join(" · ")}</CardDescription>
          </CardHeader>
          <CardContent className="grid gap-4 sm:grid-cols-2">
            {CRITERIA.map((c) => (
              <div key={c.key} className="grid gap-1">
                <div className="flex justify-between text-[13px]">
                  <label htmlFor={`w-${c.key}`} className="font-medium">
                    {c.label}
                  </label>
                  <span className="font-mono tnum text-muted-foreground">{fmtPct(weights[c.key] / wsum, 0)}</span>
                </div>
                <Slider id={`w-${c.key}`} aria-label={`${c.label} weight`} value={[weights[c.key] * 100]} min={0} max={100} step={5} onValueChange={([v]) => onWeights({ ...weights, [c.key]: v / 100 })} />
              </div>
            ))}
          </CardContent>
        </Card>
        <Card className="flex-1">
          <CardHeader>
            <CardTitle className="text-lg">Top three mixes compared</CardTitle>
            <CardDescription>Configuration scores: CAPEX relative to the cheapest mix that meets the target; reliability from loss of supply.</CardDescription>
          </CardHeader>
          <CardContent>
            {top3.length ? (
              <ChartContainer id="mix-radar" config={mixConfig} className="aspect-auto h-72 w-full">
                <RadarChart data={mixRadar} outerRadius="70%">
                  <PolarGrid />
                  <PolarAngleAxis dataKey="criterion" tick={{ fontSize: 12 }} />
                  <PolarRadiusAxis domain={[0, 10]} tickCount={6} axisLine={false} tick={{ fontSize: 10 }} angle={90} />
                  <ChartTooltip content={<ChartTooltipContent valueFormatter={(v) => fmt(v, 1)} />} />
                  <ChartLegend content={<ChartLegendContent />} />
                  {top3.map((_, i) => (
                    <Radar key={i} dataKey={`m${i + 1}`} stroke={`var(--color-m${i + 1})`} fill={`var(--color-m${i + 1})`} fillOpacity={0.06} strokeWidth={2} isAnimationActive={false} dot={{ r: 3 }} />
                  ))}
                </RadarChart>
              </ChartContainer>
            ) : (
              <p className="text-sm text-muted-foreground">The search is still running.</p>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
