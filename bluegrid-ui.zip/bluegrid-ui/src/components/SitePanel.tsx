import { useEffect, useState, type ReactNode } from "react";
import { AlertTriangle, Crosshair, MapPin } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectGroup, SelectItem, SelectLabel, SelectSeparator, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import type { Island, LoadSpec } from "@/lib/engine";
import { fmt } from "@/lib/format";

export const CUSTOM = "__custom__";

export interface SiteState {
  name: string;
  lat: number;
  lon: number;
  islandName: string | null; // null = custom coordinates
}

const GROUPS = ["Amindivi", "Laccadive", "Minicoy"];

function Fact({ k, v, dummy }: { k: string; v: ReactNode; dummy?: boolean }) {
  return (
    <div className="flex items-baseline justify-between gap-3 py-1">
      <dt className="text-muted-foreground text-[13px]">{k}</dt>
      <dd className="font-mono text-[13px] tnum text-right">
        {v}
        {dummy && <span className="ml-1 text-[10px] text-warn">dummy</span>}
      </dd>
    </div>
  );
}

export function SitePanel({
  islands,
  site,
  dataIsland,
  distanceKm,
  load,
  onSelectIsland,
  onSiteChange,
  onLoadChange,
}: {
  islands: Island[];
  site: SiteState;
  dataIsland: Island;
  distanceKm: number;
  load: LoadSpec;
  onSelectIsland: (name: string) => void;
  onSiteChange: (s: SiteState) => void;
  onLoadChange: (l: LoadSpec) => void;
}) {
  // local text state so typing a coordinate isn't fought by re-renders
  const [latText, setLatText] = useState(site.lat.toFixed(4));
  const [lonText, setLonText] = useState(site.lon.toFixed(4));
  useEffect(() => setLatText(site.lat.toFixed(4)), [site.lat]);
  useEffect(() => setLonText(site.lon.toFixed(4)), [site.lon]);

  const lat = Number(latText);
  const lon = Number(lonText);
  const latBad = !Number.isFinite(lat) || lat < -90 || lat > 90;
  const lonBad = !Number.isFinite(lon) || lon < -180 || lon > 180;
  const commitCoords = () => {
    if (latBad || lonBad) return;
    if (lat === site.lat && lon === site.lon) return;
    onSiteChange({ ...site, lat, lon, islandName: null, name: site.islandName ? "Custom site" : site.name });
  };

  const outside = distanceKm > 40;
  const tiny = dataIsland.landKm2 < 0.05;

  return (
    <Card className="h-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-lg">
          <MapPin className="size-4 text-magenta" aria-hidden /> Site
        </CardTitle>
        <CardDescription>Pick an island, or click the chart to drop a custom point.</CardDescription>
      </CardHeader>
      <CardContent className="flex flex-col gap-4">
        <div className="grid gap-1.5">
          <Label htmlFor="island-select">Island</Label>
          <Select value={site.islandName ?? CUSTOM} onValueChange={(v) => (v === CUSTOM ? onSiteChange({ ...site, islandName: null }) : onSelectIsland(v))}>
            <SelectTrigger id="island-select" aria-label="Island">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="max-h-80">
              {GROUPS.map((g, gi) => (
                <SelectGroup key={g}>
                  {gi > 0 && <SelectSeparator />}
                  <SelectLabel>{g} group</SelectLabel>
                  {islands
                    .filter((i) => i.group === g)
                    .map((i) => (
                      <SelectItem key={i.name} value={i.name}>
                        <span className={i.inhabited ? "font-medium" : "text-muted-foreground"}>{i.name}</span>
                      </SelectItem>
                    ))}
                </SelectGroup>
              ))}
              <SelectSeparator />
              <SelectItem value={CUSTOM}>Custom coordinates…</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="grid gap-1.5">
          <Label htmlFor="site-name">Site name</Label>
          <Input id="site-name" value={site.name} onChange={(e) => onSiteChange({ ...site, name: e.target.value })} placeholder="e.g. Kadmat east jetty" />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="grid gap-1.5">
            <Label htmlFor="site-lat">Latitude °N</Label>
            <Input
              id="site-lat"
              inputMode="decimal"
              className="font-mono tnum"
              value={latText}
              aria-invalid={latBad}
              onChange={(e) => setLatText(e.target.value)}
              onBlur={commitCoords}
              onKeyDown={(e) => e.key === "Enter" && commitCoords()}
            />
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="site-lon">Longitude °E</Label>
            <Input
              id="site-lon"
              inputMode="decimal"
              className="font-mono tnum"
              value={lonText}
              aria-invalid={lonBad}
              onChange={(e) => setLonText(e.target.value)}
              onBlur={commitCoords}
              onKeyDown={(e) => e.key === "Enter" && commitCoords()}
            />
          </div>
        </div>

        <div className="grid grid-cols-[1fr_1.2fr] gap-3">
          <div className="grid gap-1.5">
            <Label htmlFor="load-kw">Load target (kW AC)</Label>
            <Input
              id="load-kw"
              type="number"
              min={50}
              step={50}
              className="font-mono tnum"
              value={load.kw}
              onChange={(e) => {
                const v = Number(e.target.value);
                if (Number.isFinite(v) && v > 0) onLoadChange({ ...load, kw: v });
              }}
            />
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="load-profile">Load shape</Label>
            <Select value={load.profile} onValueChange={(v) => onLoadChange({ ...load, profile: v as LoadSpec["profile"] })}>
              <SelectTrigger id="load-profile">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="flat">Flat, round the clock</SelectItem>
                <SelectItem value="island">Island day–evening curve</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <Separator />

        <div className="flex flex-wrap items-center gap-1.5">
          <Badge variant="secondary">{dataIsland.group}</Badge>
          <Badge variant="secondary">{dataIsland.atoll}</Badge>
          {dataIsland.inhabited ? <Badge variant="good">Inhabited</Badge> : <Badge variant="outline">Uninhabited</Badge>}
          {site.islandName === null && (
            <Badge variant="magenta">
              <Crosshair aria-hidden /> Custom point
            </Badge>
          )}
        </div>

        <dl className="divide-y divide-border/60">
          <Fact k="Resource data from" v={`${dataIsland.name}${distanceKm > 0.05 ? ` · ${fmt(distanceKm, 1)} km` : ""}`} />
          <Fact k="Land area" v={`${fmt(dataIsland.landKm2, dataIsland.landKm2 < 0.1 ? 4 : 2)} km²`} />
          <Fact k="Atoll lagoon" v={`${fmt(dataIsland.lagoonKm2, 1)} km²`} dummy={dataIsland.lagoonSrc === "DUMMY"} />
          <Fact k="Population (2011)" v={dataIsland.population ? fmt(dataIsland.population) : "–"} />
          <Fact k="To 1,000 m isobath" v={`${fmt(dataIsland.distTo1000mKm, 1)} km`} dummy />
        </dl>

        {(outside || tiny) && (
          <div className="flex flex-col gap-2">
            {outside && (
              <p className="flex gap-2 rounded-md bg-warn-soft p-2.5 text-[13px] text-warn">
                <AlertTriangle className="mt-0.5 size-4 shrink-0" aria-hidden />
                This point is {fmt(distanceKm, 0)} km from the nearest island, so its resource figures are borrowed from {dataIsland.name}.
              </p>
            )}
            {tiny && (
              <p className="flex gap-2 rounded-md bg-warn-soft p-2.5 text-[13px] text-warn">
                <AlertTriangle className="mt-0.5 size-4 shrink-0" aria-hidden />
                {dataIsland.name} has under 0.05 km² of land. Land-based wind turbines and a shore OTEC plant are impractical here.
              </p>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
