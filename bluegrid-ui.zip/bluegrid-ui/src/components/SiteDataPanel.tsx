import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableFooter, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { MONTHS, type MonthlySeries, type SimResult } from "@/lib/engine";
import { fmt, fmtPct } from "@/lib/format";

export function SiteDataPanel({ m, r, islandName }: { m: MonthlySeries; r: SimResult; islandName: string }) {
  const rows = r.monthly ?? [];
  const tot = (k: keyof (typeof rows)[number]) => rows.reduce((s, x) => s + (x[k] as number), 0);
  return (
    <div className="grid gap-4">
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Pre-loaded monthly resource · {islandName}</CardTitle>
          <CardDescription>Dummy data shaped on NIOT LiDAR, Global Solar Atlas and NIOT OTEC profiles. Capacity factors are net of the losses listed in the workbook.</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Month</TableHead>
                <TableHead className="text-right">Wind 80 m m/s</TableHead>
                <TableHead className="text-right">Wind CF</TableHead>
                <TableHead className="text-right">GHI kWh/m²/d</TableHead>
                <TableHead className="text-right">FPV kWh/kWp</TableHead>
                <TableHead className="text-right">SST °C</TableHead>
                <TableHead className="text-right">ΔT °C</TableHead>
                <TableHead className="text-right">OTEC CF</TableHead>
                <TableHead className="text-right">Wave kW/m</TableHead>
                <TableHead className="text-right">Wave CF</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {MONTHS.map((mo, i) => (
                <TableRow key={mo}>
                  <TableCell>{mo}</TableCell>
                  <TableCell className="text-right font-mono">{fmt(m.ws80[i], 2)}</TableCell>
                  <TableCell className="text-right font-mono">{fmtPct(m.windCF[i])}</TableCell>
                  <TableCell className="text-right font-mono">{fmt(m.ghi[i], 2)}</TableCell>
                  <TableCell className="text-right font-mono">{fmt(m.pvoutMonth[i], 1)}</TableCell>
                  <TableCell className="text-right font-mono">{fmt(m.sst[i], 2)}</TableCell>
                  <TableCell className="text-right font-mono">{fmt(m.dT[i], 2)}</TableCell>
                  <TableCell className="text-right font-mono">{fmtPct(m.otecCF[i])}</TableCell>
                  <TableCell className="text-right font-mono">{fmt(m.waveP[i], 1)}</TableCell>
                  <TableCell className="text-right font-mono">{fmtPct(m.waveCF[i])}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Simulated energy balance for the current mix</CardTitle>
          <CardDescription>MWh per month from the hourly dispatch. Coverage is the share of load met without diesel.</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Month</TableHead>
                <TableHead className="text-right">Wind</TableHead>
                <TableHead className="text-right">Solar</TableHead>
                <TableHead className="text-right">OTEC</TableHead>
                <TableHead className="text-right">Wave</TableHead>
                <TableHead className="text-right">Load</TableHead>
                <TableHead className="text-right">Delivered</TableHead>
                <TableHead className="text-right">Diesel</TableHead>
                <TableHead className="text-right">Spilled</TableHead>
                <TableHead className="text-right">Coverage</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {rows.map((x) => (
                <TableRow key={x.month}>
                  <TableCell>{x.month}</TableCell>
                  {(["wind", "fpv", "otec", "wave", "load", "delivered", "diesel", "curtailed"] as const).map((k) => (
                    <TableCell key={k} className="text-right font-mono">
                      {fmt(x[k], 0)}
                    </TableCell>
                  ))}
                  <TableCell className="text-right font-mono">{fmtPct(x.coverage)}</TableCell>
                </TableRow>
              ))}
            </TableBody>
            <TableFooter>
              <TableRow>
                <TableCell>Year</TableCell>
                {(["wind", "fpv", "otec", "wave", "load", "delivered", "diesel", "curtailed"] as const).map((k) => (
                  <TableCell key={k} className="text-right font-mono">
                    {fmt(tot(k), 0)}
                  </TableCell>
                ))}
                <TableCell className="text-right font-mono">{fmtPct(r.reFraction)}</TableCell>
              </TableRow>
            </TableFooter>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
