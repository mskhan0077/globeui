import { useEffect, useMemo } from "react";
import L from "leaflet";
import { Circle, CircleMarker, MapContainer, Marker, Polygon, Polyline, ScaleControl, TileLayer, Tooltip, useMap, useMapEvents } from "react-leaflet";
import type { Island } from "@/lib/engine";

export type Basemap = "chart" | "ocean" | "osm";

// Simplified SW-India coastline (Kanyakumari → Goa) so the offline sea chart keeps its bearings.
const MAINLAND: [number, number][] = [
  [8.08, 77.54], [8.38, 77.0], [8.52, 76.92], [8.88, 76.58], [9.25, 76.42], [9.6, 76.32], [9.97, 76.24],
  [10.35, 76.1], [10.75, 75.92], [11.25, 75.77], [11.7, 75.53], [11.87, 75.35], [12.25, 75.1], [12.6, 74.97],
  [12.87, 74.83], [13.35, 74.7], [13.8, 74.6], [14.3, 74.43], [14.8, 74.12], [15.2, 73.95], [15.6, 73.75],
  [15.6, 79], [8.0, 79],
];
const LAT_LINES = [8, 9, 10, 11, 12, 13];
const LON_LINES = [71, 72, 73, 74, 75, 76];

const TILES: Record<Exclude<Basemap, "chart">, { url: string; attribution: string; maxZoom: number }> = {
  ocean: {
    url: "https://server.arcgisonline.com/ArcGIS/rest/services/Ocean/World_Ocean_Base/MapServer/tile/{z}/{y}/{x}",
    attribution: "Tiles © Esri — GEBCO, NOAA, Garmin, HERE and others",
    maxZoom: 13,
  },
  osm: {
    url: "https://tile.openstreetmap.org/{z}/{x}/{y}.png",
    attribution: "© OpenStreetMap contributors",
    maxZoom: 18,
  },
};

const pinIcon = L.divIcon({
  className: "",
  iconSize: [28, 28],
  iconAnchor: [14, 14],
  html: `<svg width="28" height="28" viewBox="0 0 28 28" aria-hidden="true"><circle cx="14" cy="14" r="9" fill="none" stroke="var(--magenta)" stroke-width="2"/><path d="M14 1v8M14 19v8M1 14h8M19 14h8" stroke="var(--magenta)" stroke-width="2"/></svg>`,
});

const label = (text: string) => L.divIcon({ className: "graticule-text", html: text, iconSize: [40, 14], iconAnchor: [-3, 14] });

function ClickToPick({ onPick }: { onPick: (lat: number, lon: number) => void }) {
  useMapEvents({ click: (e) => onPick(Number(e.latlng.lat.toFixed(4)), Number(e.latlng.lng.toFixed(4))) });
  return null;
}

function FlyTo({ target, focusKey }: { target: [number, number]; focusKey: number }) {
  const map = useMap();
  useEffect(() => {
    if (focusKey > 0) map.flyTo(target, Math.max(map.getZoom(), 10), { duration: 0.8 });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [focusKey]);
  return null;
}

function FitAll({ islands, fitKey }: { islands: Island[]; fitKey: number }) {
  const map = useMap();
  useEffect(() => {
    if (fitKey > 0) map.flyToBounds(L.latLngBounds(islands.map((i) => [i.lat, i.lon])), { padding: [24, 24], duration: 0.8 });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fitKey]);
  return null;
}

export function SiteMap({
  islands,
  selectedIsland,
  point,
  isCustom,
  basemap,
  onTileError,
  onSelectIsland,
  onPick,
  focusKey,
  fitKey,
}: {
  islands: Island[];
  selectedIsland: string;
  point: [number, number];
  isCustom: boolean;
  basemap: Basemap;
  onTileError: () => void;
  onSelectIsland: (name: string) => void;
  onPick: (lat: number, lon: number) => void;
  focusKey: number;
  fitKey: number;
}) {
  // One lagoon disc per atoll, sized from its real lagoon area.
  const lagoons = useMemo(() => {
    const byAtoll = new Map<string, Island[]>();
    islands.forEach((i) => byAtoll.set(i.atoll, [...(byAtoll.get(i.atoll) ?? []), i]));
    return [...byAtoll.entries()]
      .map(([atoll, list]) => ({
        atoll,
        lat: list.reduce((s, i) => s + i.lat, 0) / list.length,
        lon: list.reduce((s, i) => s + i.lon, 0) / list.length,
        radiusM: Math.sqrt(list[0].lagoonKm2 / Math.PI) * 1000,
      }))
      .filter((l) => l.radiusM > 0);
  }, [islands]);

  const bounds = useMemo(() => L.latLngBounds(islands.map((i) => [i.lat, i.lon])).pad(0.08), [islands]);
  const sel = islands.find((i) => i.name === selectedIsland);

  return (
    <MapContainer
      bounds={bounds}
      className="absolute inset-0 map-crosshair"
      zoomSnap={0.25}
      minZoom={5}
      maxZoom={14}
      worldCopyJump={false}
      attributionControl
    >
      {basemap !== "chart" && (
        <TileLayer
          key={basemap}
          url={TILES[basemap].url}
          attribution={TILES[basemap].attribution}
          maxZoom={TILES[basemap].maxZoom}
          eventHandlers={{ tileerror: onTileError }}
        />
      )}
      {basemap === "chart" && (
        <>
          <Polygon positions={MAINLAND} className="chart-land" interactive={false} />
          {LAT_LINES.map((lat) => (
            <Polyline key={`lat${lat}`} positions={[[lat, 70], [lat, 79]]} className="chart-grid" interactive={false} />
          ))}
          {LON_LINES.map((lon) => (
            <Polyline key={`lon${lon}`} positions={[[6, lon], [16, lon]]} className="chart-grid" interactive={false} />
          ))}
          {LAT_LINES.map((lat) => (
            <Marker key={`ll${lat}`} position={[lat, 71]} icon={label(`${lat}°N`)} interactive={false} />
          ))}
          {LON_LINES.slice(1, 5).map((lon) => (
            <Marker key={`lo${lon}`} position={[8, lon]} icon={label(`${lon}°E`)} interactive={false} />
          ))}
        </>
      )}
      {lagoons.map((l) => (
        <Circle key={l.atoll} center={[l.lat, l.lon]} radius={l.radiusM} className="chart-lagoon" interactive={false} />
      ))}
      {islands.map((i) => (
        <CircleMarker
          key={i.name}
          center={[i.lat, i.lon]}
          radius={i.inhabited ? 6 : 4}
          bubblingMouseEvents={false}
          className={i.inhabited ? "mk-inhabited" : "mk-islet"}
          eventHandlers={{ click: () => onSelectIsland(i.name) }}
        >
          <Tooltip direction="top" offset={[0, -6]} className="island-tip">
            {i.name}
            {!i.inhabited && " · uninhabited"}
          </Tooltip>
        </CircleMarker>
      ))}
      {sel && !isCustom && <CircleMarker center={[sel.lat, sel.lon]} radius={12} interactive={false} className="mk-selected" />}
      {isCustom && <Marker position={point} icon={pinIcon} interactive={false} />}
      <ScaleControl position="bottomright" imperial={false} />
      <ClickToPick onPick={onPick} />
      <FlyTo target={point} focusKey={focusKey} />
      <FitAll islands={islands} fitKey={fitKey} />
    </MapContainer>
  );
}
