"""Convert the BlueGrid dummy CSVs into compact JSON for the web app.
Usage: python3 scripts/build_data.py <csv_dir> <out_dir>
"""
import json
import os
import sys

import pandas as pd

src, out = sys.argv[1], sys.argv[2]
os.makedirs(out, exist_ok=True)

isl = pd.read_csv(f"{src}/islands.csv")
islands = [
    {
        "name": r.island, "group": r.group, "atoll": r.atoll_or_reef, "inhabited": r.inhabited == "Y",
        "lat": float(r.lat_deg_N), "lon": float(r.lon_deg_E), "landKm2": float(r.land_area_km2),
        "landSrc": r.land_area_src, "lagoonKm2": float(r.atoll_lagoon_area_km2), "lagoonSrc": r.lagoon_area_src,
        "population": int(r.population_2011_approx), "distTo1000mKm": float(r.dist_to_1000m_isobath_km_DUMMY),
        "peakDemandKw": float(r.peak_demand_kW_DUMMY),
    }
    for r in isl.itertuples()
]

w = pd.read_csv(f"{src}/wind_monthly.csv")
s = pd.read_csv(f"{src}/solar_monthly.csv")
o = pd.read_csv(f"{src}/otec_monthly.csv")
v = pd.read_csv(f"{src}/wave_monthly.csv")
r4 = lambda x: [round(float(a), 4) for a in x]
monthly = {}
for name in isl.island:
    W, S, O, V = (d[d.island == name].sort_values("month_num") for d in (w, s, o, v))
    monthly[name] = {
        "hours": [int(h) for h in W.hours],
        "ws80": r4(W.ws_mean_80m_ms), "windCF": r4(W.cf_net_after_losses), "windPD": r4(W.wind_power_density_80m_Wm2),
        "ghi": r4(S.ghi_kWh_m2_day), "pvoutMonth": r4(S.pvout_kWh_kWp_month), "fpvCF": r4(S.cf_fpv), "tAmb": r4(S.t_ambient_C),
        "sst": r4(O.sst_C), "t1000": r4(O.t_1000m_C), "dT": r4(O.delta_T_C), "otecCF": r4(O.cf_otec),
        "waveP": r4(V.wave_power_kW_per_m), "hs": r4(V.hs_m), "waveCF": r4(V.cf_wec_net),
    }

h = pd.read_csv(f"{src}/hourly_by_island/hourly_Kadmat.csv")
hourly = {
    "island": "Kadmat",
    "month": [int(m) - 1 for m in h.month_num],
    "cfWind": r4(h.cf_wind), "cfFpv": r4(h.cf_fpv), "cfOtec": r4(h.cf_otec), "cfWave": r4(h.cf_wave),
    "loadShape": [round(float(x) / 1000, 4) for x in h.load_island_profile_kW],
}

tp = pd.read_csv(f"{src}/tech_params.csv")
fp = pd.read_csv(f"{src}/finance_params.csv")
key = {"Wind": "wind", "Floating Solar PV": "fpv", "OTEC": "otec", "Wave": "wave", "BESS": "bess", "Diesel (baseline)": "diesel"}
def num(x):
    try:
        return float(str(x).split()[0].replace("≈", "").replace(",", ""))
    except ValueError:
        return None
tech = {}
for r in tp.itertuples():
    tech[key[r.technology]] = {
        "label": r.technology, "unit": r.cost_unit, "capexIsland": float(r.capex_island_INR),
        "opexPerUnitYr": float(r.opex_INR_per_unit_yr), "lifetimeYr": float(r.lifetime_yr),
        "lcaG": num(r.lifecycle_gCO2_per_kWh), "trl": num(str(r.TRL).replace("–", " ")),
        "capexSource": r.capex_source_and_basis,
    }
fin = {r.parameter: (float(r.value) if str(r.value).replace(".", "", 1).replace("-", "", 1).isdigit() else r.value)
       for r in fp.itertuples()}
fin = {k: (float(v) if not isinstance(v, str) else float(v)) for k, v in fin.items()}

for name, obj in [("islands", islands), ("monthly", monthly), ("hourlyRef", hourly),
                  ("params", {"tech": tech, "finance": fin})]:
    with open(f"{out}/{name}.json", "w") as f:
        json.dump(obj, f, separators=(",", ":"))
    print(name, os.path.getsize(f"{out}/{name}.json") // 1024, "KB")
