"""
BlueGrid (CHE03) - synthetic / dummy dataset generator for Lakshadweep island microgrids.

Everything produced here is SYNTHETIC. Monthly shapes and magnitudes are anchored to
published figures (problem statement, INCOIS/NIOT papers, IRENA/OES cost ranges, Indian
benchmark costs) so the numbers behave realistically, but they are NOT measurements.
Swap each CSV for the real dataset (see Sources sheet / README) before any real decision.

Run:  python generate_dummy_data.py  [--seed 42] [--out csv]
Outputs tidy CSVs (one row per island-month, or per hour) that load straight into pandas.
"""
import argparse
import os

import numpy as np
import pandas as pd
from scipy.special import gamma as G
from scipy.stats import norm

MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
DAYS = np.array([31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31])
HOURS = DAYS * 24
SEASON = ["NE monsoon / winter", "NE monsoon / winter", "Pre-monsoon", "Pre-monsoon", "Pre-monsoon",
          "SW monsoon", "SW monsoon", "SW monsoon", "SW monsoon", "Post-monsoon", "Post-monsoon",
          "NE monsoon / winter"]
MONSOON = np.array([0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0], dtype=bool)

# ---------------------------------------------------------------- islands
# multipliers are relative to the reference island for each resource (Kadmat for wind/solar,
# Kavaratti for OTEC, Agatti for wave). Fields marked DUMMY must be replaced with real data.
# 36 islands/islets, north -> south. Islet list assembled from Wikipedia atoll pages; official
# "36 islands" lists differ slightly between sources (sand cays, Parali I eroded in 2017) - verify.
# lagoon_src / area_src: "wiki" = Wikipedia atoll/islet page, "approx" = rounded literature value, "DUMMY".
_I = [
 # island, group, atoll/reef, inhabited, lat, lon, land_km2, area_src, lagoon_km2, lagoon_src, pop2011, wind, ghi, sst, wave, d1000, peak_kW
 ["Cherbaniani North", "Amindivi", "Cherbaniani Reef", "N", 12.305, 71.885, 0.005, "wiki(split)", 57.46, "wiki", 0, 1.06, 0.985, -0.26, 1.00, 3.0, 0],
 ["Cherbaniani Middle", "Amindivi", "Cherbaniani Reef", "N", 12.295, 71.882, 0.005, "wiki(split)", 57.46, "wiki", 0, 1.06, 0.985, -0.26, 1.00, 3.0, 0],
 ["Cherbaniani South", "Amindivi", "Cherbaniani Reef", "N", 12.283, 71.878, 0.005, "wiki(split)", 57.46, "wiki", 0, 1.06, 0.985, -0.26, 1.00, 3.0, 0],
 ["Byramgore Middle", "Amindivi", "Byramgore Reef", "N", 11.870, 71.830, 0.0005, "wiki(split)", 172.59, "wiki", 0, 1.05, 0.985, -0.19, 1.00, 3.5, 0],
 ["Byramgore South", "Amindivi", "Byramgore Reef", "N", 11.828, 71.839, 0.0005, "wiki(split)", 172.59, "wiki", 0, 1.05, 0.985, -0.19, 1.00, 3.5, 0],
 ["Chetlat", "Amindivi", "Chetlat", "Y", 11.693, 72.710, 1.04, "approx", 1.6, "DUMMY", 2347, 1.02, 0.990, -0.15, 0.92, 4.6, 550],
 ["Bitra", "Amindivi", "Bitra Par", "Y", 11.600, 72.180, 0.105, "approx", 45.6, "DUMMY", 271, 1.03, 0.990, -0.15, 0.95, 3.2, 80],
 ["Kiltan", "Amindivi", "Kiltan", "Y", 11.4833, 73.000, 1.63, "approx", 1.8, "DUMMY", 3946, 1.01, 0.990, -0.10, 0.90, 4.0, 900],
 ["Kadmat", "Amindivi", "Kadmat", "Y", 11.2236, 72.7766, 3.12, "approx", 37.5, "DUMMY", 5404, 1.00, 0.995, -0.05, 0.90, 4.2, 1200],
 ["Perumal Par North", "Amindivi", "Perumal Par", "N", 11.209, 72.104, 0.001, "wiki", 83.02, "wiki", 0, 1.04, 0.990, -0.10, 0.98, 3.3, 0],
 ["Perumal Par Middle", "Amindivi", "Perumal Par", "N", 11.198, 72.096, 0.0064, "wiki", 83.02, "wiki", 0, 1.04, 0.990, -0.10, 0.98, 3.3, 0],
 ["Perumal Par South", "Amindivi", "Perumal Par", "N", 11.150, 72.0875, 0.0098, "wiki", 83.02, "wiki", 0, 1.04, 0.990, -0.10, 0.98, 3.3, 0],
 ["Amini", "Amindivi", "Pitti Bank", "Y", 11.1237, 72.7262, 2.59, "approx", 155.09, "wiki", 7661, 0.99, 0.995, -0.05, 0.88, 4.5, 1800],
 ["Parali I (eroded 2017)", "Laccadive", "Bangaram Atoll", "N", 10.958, 72.334, 0.0, "wiki", 36.0, "wiki", 0, 1.02, 1.000, 0.00, 0.97, 3.7, 0],
 ["Parali II", "Laccadive", "Bangaram Atoll", "N", 10.955, 72.330, 0.045, "wiki(split)", 36.0, "wiki", 0, 1.02, 1.000, 0.00, 0.97, 3.7, 0],
 ["Parali III", "Laccadive", "Bangaram Atoll", "N", 10.952, 72.326, 0.044, "wiki(split)", 36.0, "wiki", 0, 1.02, 1.000, 0.00, 0.97, 3.7, 0],
 ["Thinnakara", "Laccadive", "Bangaram Atoll", "N", 10.945, 72.315, 0.522, "wiki", 36.0, "wiki", 0, 1.02, 1.000, 0.00, 0.97, 3.6, 80],
 ["Bangaram", "Laccadive", "Bangaram Atoll", "N", 10.940, 72.286, 0.623, "wiki", 36.0, "wiki", 0, 1.02, 1.000, 0.00, 0.97, 3.4, 150],
 ["South Bangaram Cay", "Laccadive", "Bangaram Atoll", "N", 10.933, 72.278, 0.001, "wiki", 36.0, "wiki", 0, 1.02, 1.000, 0.00, 0.97, 3.4, 0],
 ["Kalpitti", "Laccadive", "Agatti", "N", 10.885, 72.205, 0.03, "approx", 17.5, "DUMMY", 0, 1.02, 1.000, 0.00, 1.00, 3.0, 0],
 ["Agatti", "Laccadive", "Agatti", "Y", 10.8573, 72.1946, 2.70, "wiki", 17.5, "DUMMY", 7566, 1.02, 1.000, 0.00, 1.00, 3.0, 2200],
 ["Pitti (Bird Island)", "Laccadive", "Pitti Bank", "N", 10.833, 72.633, 0.01, "wiki", 155.09, "wiki", 0, 1.02, 1.000, 0.00, 0.95, 3.5, 0],
 ["Andrott", "Laccadive", "Andrott", "Y", 10.8167, 73.680, 4.90, "wiki", 0.0, "DUMMY", 11191, 0.98, 1.005, 0.05, 0.95, 5.0, 2600],
 ["Kavaratti", "Laccadive", "Kavaratti", "Y", 10.5626, 72.6369, 4.22, "wiki", 4.96, "wiki", 11221, 0.97, 1.000, 0.00, 0.90, 3.8, 3800],
 ["Cheriyam", "Laccadive", "Kalpeni Atoll", "N", 10.142, 73.664, 0.537, "wiki", 25.6, "wiki", 0, 1.00, 1.010, 0.15, 1.05, 3.5, 0],
 ["Kodithala", "Laccadive", "Kalpeni Atoll", "N", 10.110, 73.660, 0.0027, "wiki", 25.6, "wiki", 0, 1.00, 1.010, 0.15, 1.05, 3.5, 0],
 ["Suheli Cheriyakara", "Laccadive", "Suheli Par", "N", 10.120, 72.300, 0.383, "wiki", 78.76, "wiki", 0, 1.03, 1.010, 0.10, 1.05, 3.0, 0],
 ["Suheli Indira-Shastri Dweep", "Laccadive", "Suheli Par", "N", 10.090, 72.250, 0.110, "wiki", 78.76, "wiki", 0, 1.03, 1.010, 0.10, 1.05, 3.0, 0],
 ["Kalpeni", "Laccadive", "Kalpeni Atoll", "Y", 10.076, 73.646, 2.482, "wiki", 25.6, "wiki", 4419, 0.99, 1.010, 0.15, 1.05, 3.5, 1100],
 ["Pitti (Kalpeni)", "Laccadive", "Kalpeni Atoll", "N", 10.074, 73.628, 0.036, "wiki", 25.6, "wiki", 0, 1.00, 1.010, 0.15, 1.05, 3.5, 0],
 ["Koomel", "Laccadive", "Kalpeni Atoll", "N", 10.073, 73.635, 0.002, "wiki", 25.6, "wiki", 0, 1.00, 1.010, 0.15, 1.05, 3.5, 0],
 ["Tilakkam East", "Laccadive", "Kalpeni Atoll", "N", 10.069, 73.633, 0.0088, "wiki", 25.6, "wiki", 0, 1.00, 1.010, 0.15, 1.05, 3.5, 0],
 ["Tilakkam West", "Laccadive", "Kalpeni Atoll", "N", 10.069, 73.631, 0.0082, "wiki", 25.6, "wiki", 0, 1.00, 1.010, 0.15, 1.05, 3.5, 0],
 ["Suheli Valiyakara", "Laccadive", "Suheli Par", "N", 10.050, 72.270, 0.395, "wiki", 78.76, "wiki", 0, 1.03, 1.010, 0.10, 1.05, 3.0, 0],
 ["Minicoy", "Minicoy", "Minicoy Atoll", "Y", 8.2833, 73.050, 4.801, "wiki", 30.6, "DUMMY", 10447, 1.04, 1.020, 0.30, 1.10, 2.8, 2400],
 ["Viringili", "Minicoy", "Minicoy Atoll", "N", 8.270, 73.020, 0.02, "approx", 30.6, "DUMMY", 0, 1.04, 1.020, 0.30, 1.10, 2.8, 0],
]
ISLANDS = pd.DataFrame(_I, columns=[
    "island", "group", "atoll_or_reef", "inhabited", "lat_deg_N", "lon_deg_E", "land_area_km2", "land_area_src",
    "atoll_lagoon_area_km2", "lagoon_area_src", "population_2011_approx", "wind_multiplier", "ghi_multiplier",
    "sst_offset_C", "wave_multiplier", "dist_to_1000m_isobath_km_DUMMY", "peak_demand_kW_DUMMY"])
assert len(ISLANDS) == 36 and ISLANDS.island.is_unique

# ---------------------------------------------------------------- reference monthly resources
# Kadmat LiDAR-style hub-height (80 m) monthly means: SW monsoon (Jun-Sep) avg = 8.0 m/s,
# other months avg ~3.45 m/s  (problem statement: ~8 m/s monsoon, ~3.5 m/s non-monsoon).
WS80_KADMAT = np.array([3.9, 3.4, 3.0, 3.1, 4.4, 8.4, 8.9, 8.1, 6.6, 3.0, 3.2, 3.6])
WEIBULL_K = np.array([1.8, 1.8, 1.7, 1.8, 2.0, 2.4, 2.5, 2.4, 2.2, 1.7, 1.8, 1.8])
WIND_DIR = np.array([10, 350, 330, 310, 280, 255, 260, 275, 290, 340, 20, 25])  # deg from N
SHEAR_ALPHA = 0.11      # power-law shear exponent typical over open sea / small low islands
RHO_AIR = 1.15          # kg/m3, warm humid tropical air

# GHI kWh/m2/day (annual mean 5.80, problem statement); dry-season peak Mar-Apr, monsoon trough.
GHI_REF = np.array([6.1, 6.7, 7.1, 7.0, 6.1, 4.5, 4.6, 5.1, 5.5, 5.7, 5.6, 5.6])
DIFFUSE_FRAC = np.array([0.33, 0.30, 0.30, 0.33, 0.40, 0.58, 0.60, 0.55, 0.50, 0.42, 0.40, 0.36])
GTI_FACTOR_10DEG = np.array([1.07, 1.05, 1.02, 0.99, 0.97, 0.96, 0.96, 0.98, 1.01, 1.04, 1.07, 1.08])
T_AMB = np.array([27.5, 27.8, 28.6, 29.6, 29.5, 27.6, 26.6, 26.8, 27.2, 27.9, 28.0, 27.8])
T_LAGOON = np.array([28.4, 28.8, 29.6, 30.4, 30.2, 29.0, 28.2, 28.0, 28.2, 28.7, 29.0, 28.8])

# OTEC (Kavaratti reference): SST and 1000 m temperature -> mean dT ~ 22 C.
SST_REF = np.array([28.6, 29.0, 29.8, 30.5, 30.2, 29.0, 28.1, 27.8, 28.0, 28.6, 29.0, 28.8])
T1000_REF = np.array([7.0, 7.0, 6.95, 6.95, 7.0, 7.05, 7.1, 7.1, 7.05, 7.0, 7.0, 7.0])
OTEC_DT_DESIGN = 22.0       # C, design temperature difference
OTEC_PARASITIC = 0.30       # pumping + auxiliaries as fraction of design gross output
OTEC_AVAIL = 0.92
OTEC_CAP = 1.05             # max net output vs rated (generator margin)
DEPTHS = [0, 10, 25, 50, 75, 100, 125, 150, 200, 250, 300, 350, 400, 500, 600, 700, 800, 900, 1000, 1100, 1200]
BASE_PROFILE = [29.0, 28.9, 28.7, 28.2, 26.5, 23.5, 20.5, 18.0, 15.2, 14.1, 13.4, 12.8, 12.2, 11.0,
                10.2, 9.4, 8.6, 7.8, 7.0, 6.5, 6.1]
MLD = np.array([45, 40, 30, 25, 30, 55, 65, 60, 50, 45, 50, 50])          # mixed layer depth, m
THERMO_ANOM = np.array([0.5, 0.5, 0.3, 0.3, 0.3, -0.8, -1.5, -1.5, -1.5, -0.5, 0.5, 0.5])

# Wave (Agatti reference): annual mean ~13.7 kW/m, monsoon > 28 kW/m.
WAVE_P_REF = np.array([6, 5, 5, 6, 12, 30, 34, 28, 18, 8, 6, 6], dtype=float)
WAVE_TE = np.array([6.5, 6.3, 6.2, 6.5, 7.5, 8.8, 9.0, 8.8, 8.3, 7.0, 6.6, 6.5])
WAVE_DIR = np.array([320, 310, 300, 290, 260, 245, 250, 255, 265, 290, 320, 330])
WEC_RATED_KW = 250.0
WEC_CAPTURE_WIDTH_M = 6.0   # effective wave-to-wire capture width
WEC_AVAIL = 0.90            # availability of an early-stage WEC array

# Floating PV loss chain (multiplicative)
PV_LOSSES = {"soiling_salt": 0.03, "mismatch": 0.015, "dc_wiring": 0.015, "inverter": 0.025,
             "ac_transformer": 0.015, "availability": 0.02, "humidity_PID": 0.02,
             "near_shading": 0.01, "spectral_IAM": 0.02}
PV_TEMP_COEF = -0.0035      # /C (mono PERC / TOPCon class)
FPV_THERMAL_K = 0.020       # C per W/m2 (floating = better cooling than ground-mount ~0.03)
WIND_LOSSES = 0.10          # availability 3 + wake 3 + electrical 2 + other 2 (%)

# Generic 500 kW IEC class III turbine, rotor ~54 m (NOT a specific product)
PC_V = np.array([0, 2.5, 3, 3.5, 4, 4.5, 5, 5.5, 6, 6.5, 7, 7.5, 8, 8.5, 9, 9.5, 10, 10.5, 11, 11.5, 12, 25, 25.01, 40])
PC_P = np.array([0, 0, 5, 15, 28, 45, 65, 88, 115, 147, 183, 223, 267, 313, 357, 398, 435, 465, 486, 497, 500, 500, 0, 0])
TURBINE_RATED = 500.0


def power_curve(v):
    return np.interp(v, PC_V, PC_P)


def weibull_cf(mean_v, k):
    c = mean_v / G(1 + 1 / k)
    v = np.arange(0, 40, 0.02)
    pdf = (k / c) * (v / c) ** (k - 1) * np.exp(-(v / c) ** k)
    return float(np.trapezoid(power_curve(v) * pdf, v) / TURBINE_RATED)


def otec_net_factor(dT):
    gross = (np.asarray(dT) / OTEC_DT_DESIGN) ** 2
    net = (gross - OTEC_PARASITIC) / (1 - OTEC_PARASITIC)
    return np.clip(net, 0, OTEC_CAP)


def solar_cos_zenith(lat, lon, ts):
    n = ts.dayofyear.values
    hour = ts.hour.values + 0.5                     # mid-hour, IST
    B = 2 * np.pi * (n - 81) / 364
    eot = 9.87 * np.sin(2 * B) - 7.53 * np.cos(B) - 1.5 * np.sin(B)
    decl = np.radians(23.45 * np.sin(np.radians(360 / 365 * (284 + n))))
    solar_time = hour + (4 * (lon - 82.5) + eot) / 60
    w = np.radians(15 * (solar_time - 12))
    phi = np.radians(lat)
    return np.sin(phi) * np.sin(decl) + np.cos(phi) * np.cos(decl) * np.cos(w)


def ar1(n, phi, rng):
    e = rng.standard_normal(n)
    z = np.empty(n)
    z[0] = e[0]
    s = np.sqrt(1 - phi ** 2)
    for i in range(1, n):
        z[i] = phi * z[i - 1] + s * e[i]
    return z


def rescale_monthly(x, month_idx, target_means):
    x = x.copy()
    for m in range(12):
        sel = month_idx == m
        cur = x[sel].mean()
        if cur > 0:
            x[sel] *= target_means[m] / cur
    return x


def slug(name):
    return "".join(c if c.isalnum() else "_" for c in name).strip("_").replace("__", "_")


def hourly_year(isl, rng, pr_other, with_lidar=False):
    """Synthetic 8760-h typical year for one island (Series `isl` from ISLANDS)."""
    ts = pd.date_range("2025-01-01 00:00", "2025-12-31 23:00", freq="h")
    n = len(ts)
    mi = ts.month.values - 1
    hr = ts.hour.values

    # wind @80 m: AR(1) gaussian -> weibull marginal, diurnal sea-breeze, exact monthly means
    u = np.clip(norm.cdf(ar1(n, 0.96, rng)), 1e-6, 1 - 1e-6)
    k_h = WEIBULL_K[mi]
    v80_tgt = WS80_KADMAT * isl.wind_multiplier
    c_h = v80_tgt[mi] / G(1 + 1 / k_h)
    v80 = c_h * (-np.log(1 - u)) ** (1 / k_h)
    diurnal = np.where(MONSOON[mi], 0.03, 0.10) * np.cos(2 * np.pi * (hr - 15) / 24)
    v80 = v80 * (1 + diurnal)
    v80 = rescale_monthly(v80, mi, v80_tgt)
    alpha = np.clip(SHEAR_ALPHA + 0.025 * ar1(n, 0.9, rng) - 0.02 * np.cos(2 * np.pi * (hr - 14) / 24), 0.04, 0.22)
    wdir = (WIND_DIR[mi] + 18 * ar1(n, 0.9, rng)) % 360
    ti = np.clip(0.075 + 0.015 * rng.standard_normal(n) + 0.25 / np.maximum(v80, 1.0), 0.04, 0.30)
    avail = (rng.random(n) > 0.015).astype(int)

    lidar = pd.DataFrame({"timestamp_IST": ts.strftime("%Y-%m-%d %H:%M"), "month_num": mi + 1, "hour": hr})
    for h in [40, 60, 80, 100, 120, 150]:
        lidar[f"ws_{h}m_ms"] = np.round(v80 * (h / 80) ** alpha, 2)
    lidar["wdir_80m_deg"] = np.round(wdir, 0)
    lidar["ti_80m"] = np.round(ti, 3)
    lidar["shear_alpha"] = np.round(alpha, 3)
    lidar["data_valid_flag"] = avail

    # solar: Haurwitz clear sky * daily clearness (beta) * hourly cloud noise -> monthly targets
    cz = solar_cos_zenith(isl.lat_deg_N, isl.lon_deg_E, ts)
    cs = np.where(cz > 0.01, 1098 * cz * np.exp(-0.057 / np.maximum(cz, 0.01)), 0.0)
    ghi_tgt_Wh = GHI_REF * isl.ghi_multiplier * 1000 / 24  # mean W/m2 over all hours
    day_id = ts.dayofyear.values - 1
    kd = np.empty(365)
    day_month = pd.date_range("2025-01-01", periods=365, freq="D").month.values - 1
    cs_daily = pd.Series(cs).groupby(day_id).sum().values / 1000
    for m in range(12):
        sel = day_month == m
        r = min(GHI_REF[m] * isl.ghi_multiplier / cs_daily[sel].mean(), 0.97)
        conc = 6.0 if MONSOON[m] else 25.0
        kd[sel] = rng.beta(r * conc, (1 - r) * conc, sel.sum())
    hourly_noise = np.clip(1 + 0.08 * rng.standard_normal(n), 0.6, 1.25)
    ghi = cs * kd[day_id] * hourly_noise
    ghi = rescale_monthly(ghi, mi, ghi_tgt_Wh)
    ghi = np.minimum(ghi, 1.08 * cs)
    ghi = rescale_monthly(ghi, mi, ghi_tgt_Wh)
    t_amb = T_AMB[mi] + 1.6 * np.cos(2 * np.pi * (hr - 14) / 24) + 0.3 * ar1(n, 0.9, rng)

    # OTEC: daily-interpolated SST
    mid_doy = np.cumsum(DAYS) - DAYS / 2.0                       # mid-month day-of-year
    xs = np.r_[mid_doy[-1] - 365, mid_doy, mid_doy[0] + 365]
    t_doy = (day_id + hr / 24.0)
    sst_ref = np.r_[SST_REF[-1], SST_REF, SST_REF[0]] + isl.sst_offset_C
    sst = np.interp(t_doy, xs, sst_ref) + 0.15 * np.cos(2 * np.pi * (hr - 15) / 24)
    t1000 = np.interp(t_doy, xs, np.r_[T1000_REF[-1], T1000_REF, T1000_REF[0]])
    dT = sst - t1000

    # wave
    wave_p = WAVE_P_REF[mi] * isl.wave_multiplier * np.exp(0.45 * ar1(n, 0.985, rng) - 0.5 * 0.45 ** 2)
    wave_p = rescale_monthly(wave_p, mi, WAVE_P_REF * isl.wave_multiplier)

    # load
    shape = np.array([0.55, 0.52, 0.50, 0.49, 0.50, 0.55, 0.62, 0.68, 0.72, 0.75, 0.78, 0.80,
                      0.80, 0.79, 0.78, 0.77, 0.80, 0.88, 0.97, 1.00, 0.98, 0.90, 0.78, 0.65])
    seas = np.array([0.92, 0.94, 0.99, 1.00, 1.00, 0.93, 0.90, 0.90, 0.92, 0.95, 0.95, 0.94])
    load = shape[hr] * seas[mi] * np.clip(1 + 0.03 * rng.standard_normal(n), 0.9, 1.1)
    load = load / load.max() * 1000

    # per-kW capacity factors
    gti_h = ghi * GTI_FACTOR_10DEG[mi]
    t_cell = t_amb + FPV_THERMAL_K * gti_h
    cf_pv = gti_h / 1000 * (1 + PV_TEMP_COEF * (t_cell - 25)) * pr_other
    cf_wind = power_curve(v80) / TURBINE_RATED * (1 - WIND_LOSSES)
    cf_otec = otec_net_factor(dT) * OTEC_AVAIL
    cf_wave = np.minimum(wave_p * WEC_CAPTURE_WIDTH_M, WEC_RATED_KW) / WEC_RATED_KW * WEC_AVAIL

    hourly = pd.DataFrame({
        "timestamp_IST": ts.strftime("%Y-%m-%d %H:%M"), "month_num": mi + 1, "day_of_year": day_id + 1, "hour": hr,
        "ws_80m_ms": np.round(v80, 2), "ghi_Wm2": np.round(ghi, 1), "t_ambient_C": np.round(t_amb, 2),
        "sst_C": np.round(sst, 2), "t_1000m_C": np.round(t1000, 2), "otec_delta_T_C": np.round(dT, 2),
        "wave_power_kW_per_m": np.round(wave_p, 2),
        "load_flat_kW": 1000.0, "load_island_profile_kW": np.round(load, 1),
        "cf_wind": np.round(cf_wind, 4), "cf_fpv": np.round(cf_pv, 4),
        "cf_otec": np.round(cf_otec, 4), "cf_wave": np.round(cf_wave, 4),
    })

    return hourly, (lidar if with_lidar else None)

def main(seed=42, out="csv"):
    rng = np.random.default_rng(seed)
    os.makedirs(out, exist_ok=True)
    pr_other = float(np.prod([1 - v for v in PV_LOSSES.values()]))

    # ------------------------------------------------ monthly tables (all islands)
    wind_rows, solar_rows, otec_rows, wave_rows = [], [], [], []
    for _, isl in ISLANDS.iterrows():
        for m in range(12):
            # wind
            v80 = WS80_KADMAT[m] * isl.wind_multiplier
            k = WEIBULL_K[m]
            c = v80 / G(1 + 1 / k)
            cf = weibull_cf(v80, k)
            wind_rows.append({
                "island": isl.island, "month_num": m + 1, "month": MONTHS[m], "season": SEASON[m],
                "days": DAYS[m], "hours": HOURS[m],
                "ws_mean_80m_ms": round(v80, 2),
                "ws_mean_100m_ms": round(v80 * (100 / 80) ** SHEAR_ALPHA, 2),
                "weibull_k": k, "weibull_c_80m_ms": round(c, 2),
                "wind_power_density_80m_Wm2": round(0.5 * RHO_AIR * c ** 3 * G(1 + 3 / k), 1),
                "prevailing_dir_deg": WIND_DIR[m],
                "cf_gross_500kW_turbine": round(cf, 4),
                "cf_net_after_losses": round(cf * (1 - WIND_LOSSES), 4),
                "energy_kWh_per_kW_net": round(cf * (1 - WIND_LOSSES) * HOURS[m], 1),
            })
            # solar (floating PV, 10 deg tilt)
            ghi = GHI_REF[m] * isl.ghi_multiplier
            dif = ghi * DIFFUSE_FRAC[m]
            gti = ghi * GTI_FACTOR_10DEG[m]
            # daylight-weighted irradiance ~ GHI*1000/9.5h
            g_eff = gti * 1000 / 9.5
            t_cell = T_AMB[m] + FPV_THERMAL_K * g_eff
            pr = (1 + PV_TEMP_COEF * (t_cell - 25)) * pr_other
            solar_rows.append({
                "island": isl.island, "month_num": m + 1, "month": MONTHS[m], "season": SEASON[m],
                "days": DAYS[m], "hours": HOURS[m],
                "ghi_kWh_m2_day": round(ghi, 3), "dif_kWh_m2_day": round(dif, 3),
                "dni_kWh_m2_day": round((ghi - dif) / 0.8, 3),
                "gti_10deg_kWh_m2_day": round(gti, 3),
                "ghi_kWh_m2_month": round(ghi * DAYS[m], 1),
                "t_ambient_C": T_AMB[m], "t_lagoon_surface_C": T_LAGOON[m],
                "t_cell_daylight_avg_C": round(t_cell, 1),
                "performance_ratio": round(pr, 4),
                "pvout_kWh_kWp_day": round(gti * pr, 3),
                "pvout_kWh_kWp_month": round(gti * pr * DAYS[m], 1),
                "cf_fpv": round(gti * pr / 24, 4),
            })
            # OTEC
            sst = SST_REF[m] + isl.sst_offset_C
            t1000 = T1000_REF[m]
            dT = sst - t1000
            nf = float(otec_net_factor(dT))
            otec_rows.append({
                "island": isl.island, "month_num": m + 1, "month": MONTHS[m], "season": SEASON[m],
                "hours": HOURS[m],
                "sst_C": round(sst, 2), "t_1000m_C": t1000, "t_400m_C_LTTD_intake": round(BASE_PROFILE[12] + THERMO_ANOM[m] * 0.15, 2),
                "delta_T_C": round(dT, 2),
                "net_output_factor": round(nf, 4),
                "cf_otec": round(nf * OTEC_AVAIL, 4),
                "energy_kWh_per_kW_net": round(nf * OTEC_AVAIL * HOURS[m], 1),
                "dist_to_1000m_isobath_km_DUMMY": isl["dist_to_1000m_isobath_km_DUMMY"],
            })
            # wave
            p = WAVE_P_REF[m] * isl.wave_multiplier
            te = WAVE_TE[m]
            hs = np.sqrt(p / (0.49 * te))
            samples = p * rng.lognormal(-0.5 * 0.45 ** 2, 0.45, 20000)
            wcf = float(np.minimum(samples * WEC_CAPTURE_WIDTH_M, WEC_RATED_KW).mean() / WEC_RATED_KW)
            wave_rows.append({
                "island": isl.island, "month_num": m + 1, "month": MONTHS[m], "season": SEASON[m],
                "hours": HOURS[m],
                "hs_m": round(hs, 2), "te_s": te, "mean_wave_dir_deg": WAVE_DIR[m],
                "wave_power_kW_per_m": round(p, 2),
                "cf_wec_gross": round(wcf, 4),
                "cf_wec_net": round(wcf * WEC_AVAIL, 4),
                "energy_kWh_per_kW_net": round(wcf * WEC_AVAIL * HOURS[m], 1),
            })

    wind_m = pd.DataFrame(wind_rows)
    solar_m = pd.DataFrame(solar_rows)
    otec_m = pd.DataFrame(otec_rows)
    wave_m = pd.DataFrame(wave_rows)

    # ------------------------------------------------ OTEC temperature profile (Kavaratti)
    prof = []
    for m in range(12):
        dsst = SST_REF[m] - BASE_PROFILE[0]
        for z, tb in zip(DEPTHS, BASE_PROFILE):
            t = tb + dsst * np.exp(-z / MLD[m]) + THERMO_ANOM[m] * np.exp(-((z - 120) / 70) ** 2)
            if z >= 800:
                t = tb + (T1000_REF[m] - 7.0) + rng.normal(0, 0.02)
            prof.append({"island": "Kavaratti", "month_num": m + 1, "month": MONTHS[m],
                         "depth_m": z, "temperature_C": round(t, 2),
                         "mixed_layer_depth_m": MLD[m]})
    profile = pd.DataFrame(prof)

    # ------------------------------------------------ power curve
    pc = pd.DataFrame({"wind_speed_ms": np.arange(0, 30.5, 0.5)})
    pc["power_kW"] = power_curve(pc.wind_speed_ms).round(1)
    pc.loc[pc.wind_speed_ms > 25, "power_kW"] = 0.0
    pc["cp_approx"] = np.where(pc.wind_speed_ms > 0,
                               pc.power_kW * 1000 / (0.5 * RHO_AIR * np.pi * 27 ** 2 * pc.wind_speed_ms ** 3), 0).round(3)

    # ------------------------------------------------ hourly typical years (every island) + Kadmat LiDAR
    hdir = os.path.join(out, "hourly_by_island")
    os.makedirs(hdir, exist_ok=True)
    lidar = None
    for idx, (_, isl) in enumerate(ISLANDS.iterrows()):
        h_rng = np.random.default_rng(seed * 1000 + idx)
        hourly, lid = hourly_year(isl, h_rng, pr_other, with_lidar=(isl.island == "Kadmat"))
        hourly.insert(0, "island", isl.island)
        hourly.to_csv(os.path.join(hdir, f"hourly_{slug(isl.island)}.csv"), index=False)
        if lid is not None:
            lidar = lid

    # ------------------------------------------------ write
    ISLANDS.to_csv(f"{out}/islands.csv", index=False)
    wind_m.to_csv(f"{out}/wind_monthly.csv", index=False)
    solar_m.to_csv(f"{out}/solar_monthly.csv", index=False)
    otec_m.to_csv(f"{out}/otec_monthly.csv", index=False)
    wave_m.to_csv(f"{out}/wave_monthly.csv", index=False)
    profile.to_csv(f"{out}/otec_temperature_profile_kavaratti.csv", index=False)
    pc.to_csv(f"{out}/turbine_power_curve_500kW.csv", index=False)
    lidar.to_csv(f"{out}/lidar_kadmat_hourly.csv", index=False)
    return dict(islands=ISLANDS, wind=wind_m, solar=solar_m, otec=otec_m, wave=wave_m,
                profile=profile, pc=pc, lidar=lidar)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--out", default="csv")
    a = ap.parse_args()
    main(a.seed, a.out)
    print("done ->", a.out)
