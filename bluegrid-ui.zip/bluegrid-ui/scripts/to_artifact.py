"""Turn dist-single/index.html into a page fragment for hosting (no html/head/body wrappers)."""
import re
import sys

src = sys.argv[1] if len(sys.argv) > 1 else "dist-single/index.html"
dst = sys.argv[2] if len(sys.argv) > 2 else "dist-single/bluegrid-artifact.html"
html = open(src, encoding="utf-8").read()

def grab(tag_open, tag_close):
    out, i = [], 0
    while True:
        s = html.find(tag_open, i)
        if s < 0:
            return out
        e = html.find(tag_close, s) + len(tag_close)
        out.append(html[s:e])
        i = e

head_end = html.find("</head>") if html.find("</head>") < html.find('<script type="module"') else len(html)
title = re.search(r"<title>.*?</title>", html, re.S).group(0)
links = re.findall(r'<link[^>]+fonts\.(?:googleapis|gstatic)[^>]*>', html[:5000])
scripts = grab('<script type="module"', "</script>")
spans = []
i = 0
while True:
    a = html.find('<script', i)
    if a < 0:
        break
    b = html.find('</script>', a) + len('</script>')
    spans.append((a, b))
    i = b
inside = lambda pos: any(a <= pos < b for a, b in spans)
styles, i = [], 0
while True:
    a = html.find("<style", i)
    if a < 0:
        break
    b = html.find("</style>", a) + len("</style>")
    if not inside(a):
        styles.append(html[a:b])
    i = b
assert '<div id="root"></div>' in html
frag = "\n".join([title, *links, *styles, '<div id="root"></div>', *scripts]) + "\n"
open(dst, "w", encoding="utf-8").write(frag)
print("title:", title, "| styles:", len(styles), "| scripts:", len(scripts), "| size KB:", len(frag) // 1024)
