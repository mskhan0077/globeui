# BlueGrid – island microgrid planner (CHE03)

Interactive sizing tool for a 1 MW (net AC) hybrid renewable microgrid on any of the 36 Lakshadweep islands:
wind, floating solar PV, OTEC, wave energy and battery storage, with diesel as the top-up.

Built with **React 18 + Vite + TypeScript + Tailwind v4 + shadcn/ui** (Radix primitives), **react-leaflet** for the
sea chart, **Recharts** (shadcn chart wrapper) for bar/radar charts, and **jsPDF** for the PDF export.

> All data in `src/data/` is the synthetic dummy dataset from `BlueGrid_Lakshadweep_Dummy_Data.xlsx`.
> Replace it with the NIOT / Global Solar Atlas data before using the numbers.

## Run it

```bash
npm install
npm run dev          # http://localhost:5173
npm run build        # production build in dist/
npm run build:single # one self-contained HTML file in dist-single/
```

Node 18+ (tested on Node 22).

## What's on the page

| Area | What it does |
|---|---|
| **Sea chart** (top) | All 36 islands/islets, atoll lagoons drawn to scale. Click an island to select it, or click the water to drop a custom site. Basemaps: Esri ocean bathymetry, OpenStreetMap, or an offline sea chart (used automatically when tiles can't load). |
| **Site panel** | Island picker (grouped Amindivi / Laccadive / Minicoy), site name, latitude/longitude, load target (default 1,000 kW) and load shape (flat or island day–evening curve). Custom points borrow resource data from the nearest island and say so. |
| **Resource strip** | Wind @80 m, GHI, OTEC ΔT and wave power for the site, with 12-month sparklines. |
| **Configuration** | Sliders + number inputs for Wind (kW), Floating solar (kWp), OTEC (kW), Wave (kW), BESS (kWh). "Use lowest-cost mix" loads the top recommendation. |
| **Results** | 8,760-hour dispatch with the battery: RE energy delivered, PLF, loss of supply (LPSP), LCOE, system cost incl. diesel, CAPEX, CO₂ avoided, carbon-credit value; monthly energy balance and CAPEX bar charts. |
| **Recommendations** | Grid search over 8,505 mixes, ranked by lowest LCOE that meets the LPSP target (or by weighted score). Click a row to load it. |
| **Technology scoring** | Radar chart + table scoring each technology on Resource Potential, CAPEX, Reliability, Sustainability, with editable weights; radar of the top three mixes. |
| **Assumptions** | Discount rate, life, FX, diesel price & fuel use, carbon price, battery parameters, subsidies, and island CAPEX/O&M per technology. |
| **Export** | CSV and PDF summary for planners (site, mix, KPIs, monthly balance, scores, top ranked mixes, assumptions). |

## Calculation engine (`src/lib/engine.ts`)

- **Hourly profiles**: the Kadmat synthetic hourly year, rescaled month by month so each island's monthly capacity factors match the dataset.
- **Dispatch**: RE serves load first; surplus charges the battery (√RTE each way, C-rate and depth-of-discharge limits); remaining deficit is unmet → diesel.
- **LCOE (RE)** = (CAPEX × CRF + annual O&M) ÷ RE energy delivered to load. BESS is replaced once (year 15, 60 % of cost, discounted).
- **System cost** adds diesel fuel for unmet energy and divides by total load.
- **PLF** = energy delivered ÷ (target kW × 8,760 h).
- **Carbon**: CO₂ avoided = RE delivered × diesel emission factor (SFC × 2.68 kg/L); credits at the carbon price.
- **Scores (0–10)**: technology resource = CF ÷ best CF; CAPEX = cheapest ₹/kW ÷ own; reliability = 70 % firmness (worst-month ÷ mean CF) + 30 % TRL; sustainability from lifecycle gCO₂/kWh. Mixes: energy-weighted resource score, CAPEX vs the cheapest feasible mix, reliability from LPSP, sustainability from RE share × lifecycle intensity.

## Swapping in real data

1. Update the CSVs (same columns) in the dummy-data bundle, or regenerate them with `generate_dummy_data.py`.
2. `npm run data` (runs `scripts/build_data.py ../bluegrid/csv src/data`; adjust the path to your CSV folder).

Files produced: `islands.json`, `monthly.json`, `hourlyRef.json`, `params.json`.

## Project layout

```
src/
  App.tsx                    page layout and state
  components/
    SiteMap.tsx              react-leaflet sea chart
    SitePanel.tsx            island / name / lat-lon / load inputs
    ResourceStrip.tsx        resource tiles with sparklines
    ConfigPanel.tsx          capacity sliders
    ResultsPanel.tsx         KPIs + monthly & CAPEX bar charts
    Recommendations.tsx      ranked table + LCOE bars
    TechScoring.tsx          radar charts + weights
    AssumptionsPanel.tsx     editable finance & cost inputs
    SiteDataPanel.tsx        monthly data tables
    ExportDialog.tsx         CSV / PDF export
    ui/                      shadcn/ui components (button, card, select, slider, tabs, table, chart, …)
  lib/engine.ts              simulation, economics, scoring, optimizer
  lib/export.ts              CSV + PDF builders
  data/*.json                pre-loaded dataset
```
